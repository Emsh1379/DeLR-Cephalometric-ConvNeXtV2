﻿# Morning summary - 2026-10-06

Both overnight training runs finished and everything is saved on this computer. The Kaggle session stayed alive the
whole time. The recurring check has been cancelled.

## Results

| Run | Finished | Test1 MRE / SDR 2 mm | Test2 MRE / SDR 2 mm |
|---|---|---|---|
| Matched ablation reference (full model, 150 epochs, seed 42) | 05:33 | 1.180 mm / 85.79% | 1.571 mm / 74.16% |
| Seed replicate (phase-1 recipe, 200 epochs, seed 1) | 07:25 | 1.360 mm / 80.84% | 1.657 mm / 69.00% |
| For comparison: original phase 1 (200 epochs, seed 42) | - | 1.188 mm / 84.39% | 1.595 mm / 73.21% |

## What they mean

1. **Table 6 now has a verified reference row of equal training length.** It moved from 1.188 / 84.39 / 1.595 / 73.21
   to 1.180 / 85.79 / 1.571 / 74.16. The ablation conclusions are unchanged.
2. **Seed sensitivity is larger than hoped.** With a different seed the same 200-epoch recipe gave a Test1 MRE of
   1.360 mm instead of 1.188 mm (3.6 points lower SDR at 2 mm). The seed-1 run diverged around the peak learning rate
   (epochs 60-95) and was still improving at the end, so it had fewer effective epochs. This is one run, not an
   estimate of the spread, and it concerns phase 1 only: the final model has two further phases (528 epochs in total)
   that were not repeated.

## Changes made to the manuscript overnight

- Table 6: reference row and footnote (all models trained for 150 epochs).
- Section 2.6: the reference is the full model trained with the same 150-epoch schedule.
- Section 3.4: "rose from 1.180 to 12.616 mm"; a single refinement update costs +0.59 mm and -20.0 percentage points.
- Limitations paragraph: one sentence reporting the seed-replicate result and stating that differences of that size
  between configurations should not be interpreted.
- The submission zip contains the updated manuscript. Full detail: `manuscript_changes_2026-10-06.md`.

## For you to do

1. **Stop the Kaggle session.** Both GPUs are idle now but the session still counts against your weekly quota.
2. ~~Regenerate Figure 4~~ - done: redrawn with 1.180 and 1.571 mm and replaced in the zip.
3. **Decide how to present the seed result.** I put it in the limitations. If a reviewer is likely to ask, the stronger
   answer is to repeat all three ISBI phases with one or two more seeds (about 14 hours each on a T4).
4. **Replace the ethics placeholder** in section 2.1 ("Ethics: confirm with your institution ...").
5. **Consider softening** the abstract and conclusion advice to review "predictions flagged as uncertain": the
   uncertainty ranks errors well on Aariz (rho 0.61) but weakly on ISBI (0.14-0.19) and CephAdoAdu (0.39).
6. **Revoke the three tokens** pasted into the chat (two GitHub, one Hugging Face).
7. **GitHub:** the overnight results (`results/training_runs/`) and the checkpoint-verification report are not pushed
   yet. I did not push to the public repository while you were asleep; tell me if you want them added.

## Where things are (this folder)

- `updated_manuscript/` - manuscript, supplement, highlights, submission zip; `previous_version/` holds the files from before my edits.
- `manuscript_changes_2026-10-06.md` - every edit with before, after and reason.
- `DeLR_all_results.md` - all results and reports in one file.
- `results/manuscript_metrics/` - tables, CSVs, error arrays, uncertainty report, failure-case overlays.
- `results/training_runs/` - logs, metrics and prediction files of the two overnight runs.
