> **Update 2026-10-08:** both runs finished all three phases. Results: `SEED_REPLICATES_SUMMARY.md` in the parent folder and `checkpoints/ISBI2015_seed_replicates/` on Hugging Face. The notes below are kept for reference.

# Seed replicates on ISBI 2015 - where things stand and how to continue

## State when the computer was shut down (2026-10-08 00:40 local, 21:09 UTC on 7 Oct)

Two full three-phase runs (200 + 200 + 128 epochs) with mixed precision in the backbone.

| Run | Phase 1 result (Test1 / Test2, MRE and SDR at 2 mm) | Position |
|---|---|---|
| Seed 42 (control) | 1.171 mm / 85.75% and 1.532 mm / 75.11% | phase 2, epoch 116 of 200 |
| Seed 2 (new seed) | 1.171 mm / 85.47% and 1.556 mm / 74.47% | phase 2, epoch 134 of 200 |

Local copies of the finished phases: `results/training_runs_3phase/` (logs, metrics, predictions).

## What keeps running without this computer

The training and the Hugging Face upload both run on Kaggle. As long as the Kaggle session stays alive they continue:

- every 30 minutes the training state is uploaded to the dataset repo `emad2001/DeLR-Cephalometric-ConvNeXtV2`
  on a work branch `seedrep-wip-<n>` (latest at shutdown: `seedrep-wip-16`);
- when both seeds finish phase 3, logs, predictions and the two final checkpoints are committed to `main` under
  `checkpoints/ISBI2015_seed_replicates/`.

About 4.5 hours of training remained at shutdown.

## How to tell what happened

Open the dataset repo on Hugging Face:

- a folder `checkpoints/ISBI2015_seed_replicates/` on `main` -> the runs finished; results are there;
- no such folder, but a branch `seedrep-wip-<n>` -> the session ended early; open
  `seed_replicates_wip/state.json` on that branch to see the last saved epoch of each run.

## How to continue an interrupted run

Start a new Kaggle session (GPU T4 x2, Internet on) and give Claude the session URL and a Hugging Face write token.
The steps are: clone the repo, download and verify ISBI 2015, copy `make_train_fast.py`, `sync_hf.py`, `job3p.sh` into
the repo folder, then

    export HF_TOKEN=...                 # never write the token into a file
    python make_train_fast.py
    python sync_hf.py restore           # pulls the newest saved state
    nohup bash job3p.sh 42 0 &          # each run continues from its last completed epoch
    nohup bash job3p.sh 2 1 &
    nohup python -u sync_hf.py loop &

Nothing is repeated except the epochs since the last upload (at most 30 minutes).

## Files in this folder

- `make_train_fast.py` - builds `train_fast.py` from the repository's `train.py` (seed, backbone mixed precision, resumable state)
- `job3p.sh` - the three phases with Test1/Test2 inference after each; skips what is already done
- `sync_hf.py` - upload / restore of the training state on Hugging Face
- `kx.py`, `collect2.py`, `j1.py`, `j4.py` - the helper scripts Claude used to drive the Kaggle session

No token is stored in any of these files.
