#!/bin/bash
# usage: job3p.sh <seed> <gpu>
# Three-phase ISBI 2015 recipe. Every step is skipped if already done and every phase
# continues from its last completed epoch, so the script can simply be started again.
cd /kaggle/working/DeLR-Cephalometric-ConvNeXtV2
S=$1; export CUDA_VISIBLE_DEVICES=$2; export SEED=$1; export AMP=1
I=/kaggle/working/data/isbi
R=outputs/isbi3p_seed$S
COMMON="--dataset isbi2015 --dataset-root $I --backbone convnextv2_tiny --image-size 1024 --batch-size 2 --num-workers 2 --pixel-size-mm 0.1"
infer () {
  for SP in test1 test2; do
    python -u infer.py --dataset isbi2015 --dataset-root $I --split $SP --backbone convnextv2_tiny --image-size 1024 --batch-size 1 --pixel-size-mm 0.1 \
      --checkpoint $1/best_model.pt --output $1/${SP}_predictions.json >> $1/eval.log 2>&1 || exit 1
  done
  touch $1/DONE
  rm -f $1/last.pt
}
mkdir -p $R/phase1 $R/phase2 $R/phase3
if [ ! -f $R/phase1/DONE ]; then
  python -u train_fast.py $COMMON --epochs 200 --lr 2e-4 --output-dir $R/phase1 >> $R/phase1/train.log 2>&1 || exit 1
  infer $R/phase1
fi
if [ ! -f $R/phase2/DONE ]; then
  python -u train_fast.py $COMMON --epochs 200 --lr 5e-5 --scheduler constant --resume $R/phase1/best_model.pt --output-dir $R/phase2 >> $R/phase2/train.log 2>&1 || exit 1
  infer $R/phase2
fi
if [ ! -f $R/phase3/DONE ]; then
  python -u train_fast.py $COMMON --epochs 128 --lr 5e-5 --lr-min 1e-6 --scheduler cosine --resume $R/phase2/best_model.pt --output-dir $R/phase3 >> $R/phase3/train.log 2>&1 || exit 1
  infer $R/phase3
fi
echo "seed $S finished $(date -u +%Y-%m-%dT%H:%MZ)"
