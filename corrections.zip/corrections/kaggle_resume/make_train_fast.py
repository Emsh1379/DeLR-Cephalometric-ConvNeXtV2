"""Build train_fast.py from the repository's train.py.

Additions (no change to the model, losses, schedule or data pipeline):
  * SEED environment variable (default 42)
  * AMP=1: mixed precision in the convolutional backbone only (transformers, heads, losses, metrics stay float32)
  * full training state saved every epoch to <output-dir>/last.pt and restored automatically,
    so an interrupted phase continues from the last completed epoch
  * checkpoints are written atomically
"""
src = open("train.py").read()


def rep(a, b):
    global src
    assert src.count(a) == 1, (a[:60], src.count(a))
    src = src.replace(a, b)


rep("torch.manual_seed(42)", 'SEED = int(os.environ.get("SEED", "42"))\n    torch.manual_seed(SEED)\n    __import__("random").seed(SEED)\n    __import__("numpy").random.seed(SEED)')
rep("torch.cuda.manual_seed_all(42)", "torch.cuda.manual_seed_all(SEED)")
rep("""        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        scheduler.step()
""", """        SCALER.scale(loss).backward()
        SCALER.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        SCALER.step(optimizer)
        SCALER.update()
        scheduler.step()
""")
rep("def train_one_epoch(", '''import os
# Mixed precision is applied to the convolutional backbone / feature extractor only.
# The transformer encoders, coordinate heads, losses and metrics stay in float32,
# because landmark coordinates (0-1024) cannot be represented accurately in float16.
USE_AMP = os.environ.get("AMP", "0") == "1"
SCALER = torch.amp.GradScaler("cuda", enabled=USE_AMP, init_scale=1.0, growth_interval=500)


def enable_backbone_amp(model):
    if not USE_AMP:
        return
    original = model._feature_extractor

    def feature_extractor_amp(x):
        with torch.autocast("cuda", dtype=torch.float16):
            out = original(x)
        return {k: (v.float() if torch.is_tensor(v) else v) for k, v in out.items()}

    model._feature_extractor = feature_extractor_amp


def _atomic_save(obj, path):
    tmp = str(path) + ".tmp"
    torch.save(obj, tmp)
    os.replace(tmp, path)


def train_one_epoch(''')
rep("""    if args.freeze_backbone:
        for param in model.backbone.parameters():""", """    enable_backbone_amp(model)
    print(f"seed={SEED} backbone_amp={USE_AMP}", flush=True)

    if args.freeze_backbone:
        for param in model.backbone.parameters():""")
rep("        print(log_line)\n", "        print(log_line, flush=True)\n")
# fresh start of a resumed phase: seed best_model.pt from the previous phase, but never overwrite it on a mid-phase restart
rep("""        if same_architecture:
            torch.save(resume_checkpoint, args.output_dir / "best_model.pt")
""", """        if same_architecture and not (args.output_dir / "last.pt").exists():
            _atomic_save(resume_checkpoint, args.output_dir / "best_model.pt")
""")
rep("""    for epoch in range(1, args.epochs + 1):
""", """    start_epoch = 1
    last_path = args.output_dir / "last.pt"
    if last_path.exists():
        st = torch.load(last_path, map_location=device, weights_only=False)
        model.load_state_dict(st["state_dict"])
        optimizer.load_state_dict(st["optimizer"])
        scheduler.load_state_dict(st["scheduler"])
        SCALER.load_state_dict(st["scaler"])
        best_mre = st["best_mre"]
        start_epoch = st["epoch"] + 1
        torch.set_rng_state(st["torch_rng"].cpu())
        if torch.cuda.is_available() and st.get("cuda_rng") is not None:
            torch.cuda.set_rng_state_all([s.cpu() for s in st["cuda_rng"]])
        __import__("random").setstate(st["py_rng"])
        __import__("numpy").random.set_state(st["np_rng"])
        print(f"Restored training state from {last_path}: epoch {st['epoch']} done, best val MRE {best_mre:.3f}, "
              f"lr {optimizer.param_groups[0]['lr']:.3e}", flush=True)
    for epoch in range(start_epoch, args.epochs + 1):
""")
rep("""            torch.save(best_state, args.output_dir / "best_model.pt")
""", """            _atomic_save(best_state, args.output_dir / "best_model.pt")
        _atomic_save({
            "epoch": epoch,
            "state_dict": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": SCALER.state_dict(),
            "best_mre": best_mre,
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            "py_rng": __import__("random").getstate(),
            "np_rng": __import__("numpy").random.get_state(),
        }, last_path)
""")
open("train_fast.py", "w").write(src)
import ast
ast.parse(src)
print("train_fast.py written")
