import subprocess, os, time
def sh(c):
    r = subprocess.run(c, shell=True, capture_output=True, text=True)
    print(f"$ {c[:100]}\n{r.stdout[-2500:]}{r.stderr[-1200:]}")
    return r
sh("nvidia-smi --query-gpu=index,name,memory.used --format=csv,noheader; nproc; uptime; date -u; df -h /kaggle/working | tail -1; ls /kaggle/working; python -c 'import huggingface_hub as h; print(\"hf_hub\", h.__version__)'")
os.makedirs("/kaggle/working/data/isbi", exist_ok=True)
os.chdir("/kaggle/working")
sh("test -d DeLR-Cephalometric-ConvNeXtV2 || git clone -q https://github.com/Emsh1379/DeLR-Cephalometric-ConvNeXtV2; cd DeLR-Cephalometric-ConvNeXtV2 && git log --oneline | head -1")
ISBI = "/kaggle/working/data/isbi"; L = "private_link=37ec464af8e81ae6ebbf"
def fetch(fid, marker):
    for attempt in range(4):
        if os.path.exists(f"{ISBI}/{marker}"): return True
        r = subprocess.run(f"cd {ISBI} && wget -q --tries=2 -O tmp.rar 'https://ndownloader.figshare.com/files/{fid}?{L}' && unrar x -o+ -inul tmp.rar; rm -f tmp.rar", shell=True, capture_output=True, text=True)
        if not os.path.exists(f"{ISBI}/{marker}"):
            print("attempt", attempt, "failed:", r.stderr[-200:]); time.sleep(15)
    return os.path.exists(f"{ISBI}/{marker}")
print("annotations:", fetch(5466581, "400_senior"), "images:", fetch(5466590, "RawImage"))
sh(f"for d in {ISBI}/RawImage/*; do echo $d $(ls $d | wc -l); done; ls {ISBI}/400_junior | wc -l; ls {ISBI}/400_senior | wc -l")
