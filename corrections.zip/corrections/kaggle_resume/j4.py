import subprocess, os, time
assert os.environ.get("HF_TOKEN"), "token not in kernel env"
os.chdir("/kaggle/working/DeLR-Cephalometric-ConvNeXtV2")
assert subprocess.run(["pgrep", "-f", "job3p.sh"], capture_output=True).returncode != 0, "jobs already running"
noenv = {k: v for k, v in os.environ.items() if k != "HF_TOKEN"}       # training jobs do not get the token
for seed, gpu in ((42, 0), (2, 1)):
    subprocess.Popen(f"nohup bash job3p.sh {seed} {gpu} > /kaggle/working/job_seed{seed}.log 2>&1 &", shell=True, env=noenv)
subprocess.Popen("nohup python -u sync_hf.py loop > /kaggle/working/sync_hf.log 2>&1 &", shell=True)
time.sleep(200)
print(subprocess.run("date -u; nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader; for s in 42 2; do for p in 1 2 3; do f=outputs/isbi3p_seed$s/phase$p/train.log; [ -f $f ] && { echo seed $s phase $p; grep Restored $f | tail -1 | cut -c1-200; grep Epoch $f | tail -2 | grep -o 'Epoch [0-9/]*\\|Val MRE.*' | paste - - ; }; done; done; cat /kaggle/working/sync_hf.log /kaggle/working/job_seed*.log | tail -4; pgrep -af 'job3p|sync_hf' | cut -c1-60", shell=True, capture_output=True, text=True).stdout)
