"""Run a code file on the remote Jupyter kernel and print its output.
usage: python kx.py <codefile> [timeout_s]"""
import sys, json, uuid, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "lib"))
import requests, websocket

BASE = open(os.path.join(os.path.dirname(__file__), "base.txt")).read().strip()
KFILE = os.path.join(os.path.dirname(__file__), "kernel.txt")


def kernel_id():
    if os.path.exists(KFILE):
        kid = open(KFILE).read().strip()
        if requests.get(f"{BASE}/api/kernels/{kid}", timeout=30).status_code == 200:
            return kid
    r = requests.post(f"{BASE}/api/kernels", json={"name": "python3"}, timeout=60)
    r.raise_for_status()
    kid = r.json()["id"]
    open(KFILE, "w").write(kid)
    return kid


def run(code, timeout=110):
    kid = kernel_id()
    ws = websocket.create_connection(
        BASE.replace("https://", "wss://") + f"/api/kernels/{kid}/channels", timeout=timeout)
    mid = uuid.uuid4().hex
    ws.send(json.dumps({
        "header": {"msg_id": mid, "username": "", "session": uuid.uuid4().hex,
                   "msg_type": "execute_request", "version": "5.3"},
        "parent_header": {}, "metadata": {}, "channel": "shell",
        "content": {"code": code, "silent": False, "store_history": False,
                    "user_expressions": {}, "allow_stdin": False, "stop_on_error": True}}))
    end = time.time() + timeout
    while time.time() < end:
        try:
            m = json.loads(ws.recv())
        except websocket.WebSocketTimeoutException:
            break
        if m.get("parent_header", {}).get("msg_id") != mid:
            continue
        t, c = m["msg_type"], m["content"]
        if t == "stream":
            sys.stdout.write(c["text"])
        elif t in ("execute_result", "display_data"):
            print(c["data"].get("text/plain", ""))
        elif t == "error":
            print("\n".join(c["traceback"]))
        elif t == "status" and c["execution_state"] == "idle":
            ws.close()
            return
    print("[kx: timed out waiting for kernel]")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    run(open(sys.argv[1], encoding="utf-8").read(), int(sys.argv[2]) if len(sys.argv) > 2 else 110)
