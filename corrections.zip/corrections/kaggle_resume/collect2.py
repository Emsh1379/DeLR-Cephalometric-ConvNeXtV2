"""Check the two three-phase ISBI runs (seeds 42 and 2) and save everything available locally. Safe to re-run."""
import sys, os, json, io, contextlib, datetime
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), "lib"))
import requests
import kx

OUT = r"C:\Users\User\Downloads\corrections\results\training_runs_3phase"
REMOTE = r'''
import json, os, re, subprocess, sys
os.chdir("/kaggle/working/DeLR-Cephalometric-ConvNeXtV2")
sys.path.insert(0, ".")
import evaluate_manuscript_metrics as E
from pathlib import Path
st = {}
for seed in (42, 2):
    for ph, total in ((1, 200), (2, 200), (3, 128)):
        d = Path(f"outputs/isbi3p_seed{seed}/phase{ph}")
        log = (d / "train.log").read_text() if (d / "train.log").exists() else ""
        ep = re.findall(r"Epoch (\d+)/\d+ .*?Val MRE\(mm\): ([0-9.]+) \| SDR%\(2/2.5/3/4\): ([0-9./]+) \| ([0-9.]+)s", log)
        s = {"epochs_done": len(ep), "epochs_total": total, "traceback": "Traceback" in log}
        if ep:
            v = [float(e[1]) for e in ep]
            s.update(last_val_mre=v[-1], best_val_mre=min(v), best_epoch=v.index(min(v)) + 1, sec_per_epoch=float(ep[-1][3]))
        m = re.search(r"Checkpoint val_metrics: .*?'mre_mm': ([0-9.]+)", log)
        if m: s["resumed_from_val_mre"] = float(m.group(1))
        if (d / "deadline.txt").exists(): s["deadline_note"] = (d / "deadline.txt").read_text().strip()
        s["finished"] = (d / "DONE").exists()
        if s["finished"]:
            for split in ("test1", "test2"):
                p = d / f"{split}_predictions.json"
                gt, px, _ = E.load_isbi_gt(Path("/kaggle/working/data/isbi"), list(json.loads(p.read_text())))
                _, e = E.radial_errors_mm(p, gt, px)
                s[split] = {"n": int(e.shape[0]), "mre_mm": float(e.mean()), **{f"sdr_{t}": float((e <= t).mean() * 100) for t in (2.0, 2.5, 3.0, 4.0)}}
        if d.exists(): (d / "metrics.json").write_text(json.dumps(s, indent=1))
        st[f"seed{seed}/phase{ph}"] = s
    st[f"seed{seed}/job_alive"] = subprocess.run(["pgrep", "-f", f"job3p.sh {seed} "], capture_output=True).returncode == 0
st["utc"] = subprocess.run("date -u +%H:%M", shell=True, capture_output=True, text=True).stdout.strip()
st["uptime"] = subprocess.run("uptime -p", shell=True, capture_output=True, text=True).stdout.strip()
print("STATUS_JSON" + json.dumps(st))
'''

def main():
    os.makedirs(OUT, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    sp = os.path.join(OUT, "status.json")
    prev = json.load(open(sp)) if os.path.exists(sp) else {}
    try:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            kx.run(REMOTE, 100)
        st = json.loads(buf.getvalue().split("STATUS_JSON", 1)[1].strip().splitlines()[0])
    except Exception as ex:
        n = prev.get("_unreachable", 0) + 1
        print(f"[{stamp}] SESSION UNREACHABLE ({n} in a row): {type(ex).__name__}: {str(ex)[:120]}")
        prev["_unreachable"] = n; prev["_last_check"] = stamp
        json.dump(prev, open(sp, "w"), indent=1)
        return
    B = kx.BASE
    all_done = True
    for seed in (42, 2):
        parts = []
        for ph in (1, 2, 3):
            key = f"seed{seed}/phase{ph}"; s = st[key]
            d = os.path.join(OUT, f"seed{seed}", f"phase{ph}"); os.makedirs(d, exist_ok=True)
            if s["epochs_done"] or s["finished"]:
                names = ["train.log", "metrics.json"] + (["eval.log", "test1_predictions.json", "test2_predictions.json"] if s["finished"] else [])
                for n in names:
                    if n.endswith("predictions.json") and os.path.exists(os.path.join(d, n)):
                        continue
                    r = requests.get(f"{B}/api/contents/DeLR-Cephalometric-ConvNeXtV2/outputs/isbi3p_seed{seed}/phase{ph}/{n}", params={"content": 1, "type": "file", "format": "text"}, timeout=120)
                    if r.ok:
                        open(os.path.join(d, n), "w", encoding="utf-8", newline="\n").write(r.json()["content"])
            if s["finished"]:
                new = " (NEW)" if not prev.get(key, {}).get("finished") else ""
                parts.append(f"P{ph} FINISHED{new}: T1 {s['test1']['mre_mm']:.3f}/{s['test1']['sdr_2.0']:.2f} T2 {s['test2']['mre_mm']:.3f}/{s['test2']['sdr_2.0']:.2f} (ep {s['epochs_done']}/{s['epochs_total']}, best val {s.get('best_val_mre', s.get('resumed_from_val_mre'))})")
            elif s["epochs_done"]:
                parts.append(f"P{ph} epoch {s['epochs_done']}/{s['epochs_total']}, best val {s['best_val_mre']} @ {s['best_epoch']}, {s['sec_per_epoch']:.0f}s/ep" + ("  <-- PROBLEM: traceback" if s["traceback"] else ""))
            if ph == 3 and not s["finished"]:
                all_done = False
        alive = st[f"seed{seed}/job_alive"]
        if not alive and not st[f"seed{seed}/phase3"]["finished"]:
            parts.append("<-- PROBLEM: job not running")
        print(f"[{stamp} | UTC {st['utc']} | {st['uptime']}] seed {seed}: " + " | ".join(parts))
    if all_done:
        print("ALL DONE")
    st["_unreachable"] = 0; st["_last_check"] = stamp
    json.dump(st, open(sp, "w"), indent=1)

main()
