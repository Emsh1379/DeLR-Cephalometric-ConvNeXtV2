"""Keep the seed-replicate training state on Hugging Face so a new Kaggle session can continue it.

  python sync_hf.py restore   # download the newest saved state into outputs/ (no-op if none)
  python sync_hf.py loop      # upload every INTERVAL seconds and whenever a phase finishes; final upload to main
  python sync_hf.py once      # single upload

Rolling state goes to a work branch 'seedrep-wip-<n>' (the previous work branch is deleted after each
successful upload, so old checkpoints do not pile up). When both seeds have finished phase 3, logs,
predictions and the two final checkpoints are committed to main under FINAL_DIR.
The token is read from the HF_TOKEN environment variable and is never written to disk.
"""
import json, os, re, shutil, sys, time
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download

REPO = "emad2001/DeLR-Cephalometric-ConvNeXtV2"
WIP_DIR = "seed_replicates_wip"
FINAL_DIR = "checkpoints/ISBI2015_seed_replicates"
SEEDS = (42, 2)
INTERVAL = 30 * 60
ROOT = Path("/kaggle/working/DeLR-Cephalometric-ConvNeXtV2")
OUT = ROOT / "outputs"
STAGE = Path("/kaggle/working/hf_stage")
api = HfApi(token=os.environ["HF_TOKEN"])
SMALL = ("train.log", "eval.log", "DONE", "test1_predictions.json", "test2_predictions.json")


def wip_branches():
    refs = api.list_repo_refs(REPO, repo_type="dataset")
    out = []
    for b in refs.branches:
        m = re.fullmatch(r"seedrep-wip-(\d+)", b.name)
        if m:
            out.append((int(m.group(1)), b.name))
    return sorted(out)


def link(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(src, dst)                # consistent snapshot: checkpoints are replaced atomically
    except OSError:
        shutil.copy2(src, dst)


def phase_dirs():
    for s in SEEDS:
        for p in (1, 2, 3):
            yield s, p, OUT / f"isbi3p_seed{s}" / f"phase{p}"


def state():
    return {f"seed{s}/phase{p}": {"done": (d / "DONE").exists(),
                                  "epochs": len(re.findall(r"^Epoch \d+/", (d / "train.log").read_text(), flags=re.M)) if (d / "train.log").exists() else 0}
            for s, p, d in phase_dirs()}


def upload_wip():
    shutil.rmtree(STAGE, ignore_errors=True)
    for s, p, d in phase_dirs():
        if not d.exists():
            continue
        dst = STAGE / f"seed{s}" / f"phase{p}"
        for f in SMALL:
            if (d / f).exists():
                dst.mkdir(parents=True, exist_ok=True)
                shutil.copy2(d / f, dst / f)
        if (d / "best_model.pt").exists():
            link(d / "best_model.pt", dst / "best_model.pt")
        if (d / "last.pt").exists() and not (d / "DONE").exists():
            link(d / "last.pt", dst / "last.pt")
    if not STAGE.exists():
        print("nothing to upload yet", flush=True)
        return
    st = state()
    (STAGE / "state.json").write_text(json.dumps({"time_utc": time.strftime("%Y-%m-%d %H:%M", time.gmtime()), "state": st}, indent=1))
    old = wip_branches()
    n = (old[-1][0] + 1) if old else 1
    branch = f"seedrep-wip-{n}"
    api.create_branch(REPO, branch=branch, repo_type="dataset", exist_ok=True)
    t = time.time()
    api.upload_folder(folder_path=str(STAGE), path_in_repo=WIP_DIR, repo_id=REPO, repo_type="dataset", revision=branch,
                      commit_message="seed replicates: training state " + ", ".join(f"{k} ep{v['epochs']}{' done' if v['done'] else ''}" for k, v in st.items() if v["epochs"]))
    size = sum(f.stat().st_size for f in STAGE.rglob("*") if f.is_file()) / 2 ** 30
    print(f"[{time.strftime('%H:%M', time.gmtime())} UTC] uploaded {size:.1f} GB to {branch} in {time.time() - t:.0f} s", flush=True)
    for _, name in old:
        try:
            api.delete_branch(REPO, branch=name, repo_type="dataset")
        except Exception as ex:
            print("could not delete", name, repr(ex), flush=True)
    shutil.rmtree(STAGE, ignore_errors=True)


def restore():
    old = wip_branches()
    if not old:
        print("no saved state on Hugging Face - starting from scratch")
        return
    branch = old[-1][1]
    tmp = Path("/kaggle/working/hf_restore")
    shutil.rmtree(tmp, ignore_errors=True)
    snapshot_download(REPO, repo_type="dataset", revision=branch, allow_patterns=[f"{WIP_DIR}/*"], local_dir=str(tmp), token=os.environ["HF_TOKEN"])
    src = tmp / WIP_DIR
    print("restoring from", branch, (src / "state.json").read_text() if (src / "state.json").exists() else "")
    for s, p, d in phase_dirs():
        sd = src / f"seed{s}" / f"phase{p}"
        if sd.exists():
            d.mkdir(parents=True, exist_ok=True)
            for f in sd.iterdir():
                shutil.move(str(f), str(d / f.name))
    shutil.rmtree(tmp, ignore_errors=True)


def final():
    shutil.rmtree(STAGE, ignore_errors=True)
    for s, p, d in phase_dirs():
        dst = STAGE / f"seed{s}" / f"phase{p}"
        for f in SMALL:
            if f != "DONE" and (d / f).exists():
                dst.mkdir(parents=True, exist_ok=True)
                shutil.copy2(d / f, dst / f)
        if p == 3 and (d / "best_model.pt").exists():
            link(d / "best_model.pt", dst / "best_model.pt")
    for f in ("train_fast.py", "job3p.sh", "RESULTS.md"):
        if (ROOT / f).exists():
            shutil.copy2(ROOT / f, STAGE / f)
    api.upload_folder(folder_path=str(STAGE), path_in_repo=FINAL_DIR, repo_id=REPO, repo_type="dataset",
                      commit_message="ISBI 2015 three-phase seed replicates (seeds 42 and 2, mixed precision in the backbone)")
    print("final results committed to main under", FINAL_DIR, flush=True)
    shutil.rmtree(STAGE, ignore_errors=True)


def loop():
    last_up, last_done = 0.0, None
    while True:
        st = state()
        done = tuple(v["done"] for v in st.values())
        if time.time() - last_up >= INTERVAL or (last_done is not None and done != last_done):
            try:
                upload_wip()
                last_up = time.time()
            except Exception as ex:
                print("upload failed:", repr(ex), flush=True)
                last_up = time.time() - INTERVAL + 300          # retry in 5 minutes
        last_done = done
        if all(st[f"seed{s}/phase3"]["done"] for s in SEEDS):
            try:
                upload_wip()
                final()
            except Exception as ex:
                print("final upload failed:", repr(ex), flush=True)
            (ROOT / "SYNC_FINISHED").write_text(time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()))
            return
        time.sleep(60)


if __name__ == "__main__":
    {"restore": restore, "loop": loop, "once": upload_wip, "final": final}[sys.argv[1]]()
