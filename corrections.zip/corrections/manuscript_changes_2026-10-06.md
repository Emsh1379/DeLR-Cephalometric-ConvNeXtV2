# Changes made to the manuscript on 2026-10-06

File edited: `updated_manuscript/Manuscript_anonymised_IntOrthod.docx` (also replaced inside
`IntOrthod_submission_package.zip`). The versions from before these edits are in
`updated_manuscript/previous_version/`. The supplement, highlights and title page were not changed.

Everything was recomputed from the prediction files; the uncertainty analysis re-ran inference with
the released Aariz checkpoint, which reproduces the saved predictions to within 0.04 pixels.

## Confirmed without change

- Tables 2, 3, 4, 5, 6 and supplementary tables S1-S6: every value matches the re-run.
- Per-device table: seven devices, 150 images, weighted mean 1.105 mm.
- Landmark names in all tables and in the text (Aariz names are read from the annotation files).
- Ablation numbers (recomputed from the ablation prediction files) and the 1.188 / 1.132 / 1.124 mm
  validation values of the three ISBI training phases.
- Parameter counts: 53.9 million in total, 27.9 million in the backbone.
- Abstract, highlights and conclusions: no statement depends on the corrected items.

## Corrected

| Where | Was | Now | Why |
|---|---|---|---|
| 3.2, posterior landmarks within 2 mm | 63-76% | 63-79% | articulare is 79.33% |
| 3.2, junior-senior disagreement | about 1.3 mm at porion, gonion and condylion; 0.06 mm at sella | porion 1.41 mm, gonion 1.31 mm, condylion 0.81 mm, sella 0.03 mm | condylion is not among the highest; values recomputed on the test images |
| 3.5, correlation | rho = 0.606; r = 0.430 | rho = 0.61; r = 0.43 | re-run gives 0.605 and 0.429; two decimals are what the data support |
| 3.5, least confident decile | SDR 54.6% | 55.1% | re-run |
| 3.5, calibration | "roughly constant factor of about 4.8" | "factor of about 4 to 6 in every decile (about 5 overall)" | ratio varies from 4.0 to 6.4 across deciles |
| 3.5, added | - | 123 of 127 errors above 4 mm have above-median uncertainty, 69 are in the least confident decile; median uncertainty 0.36 vs 0.18 mm | replaces the unsupported "median of about 0.15 mm" |
| 3.5, failure cases | two patterns: contralateral ramus (low to moderate uncertainty); earrings over the temporomandibular region in most other cases | four patterns, described below | the previous description did not match the images |
| 4, landmark paragraph | posterior landmarks have "the greatest junior-senior disagreement" | porion and gonion showed the largest | condylion, articulare and ramus rank 8th, 10th and 5th of 26 |
| 4, uncertainty paragraph | "the uncertainty did not detect the case in which the network confused the two mandibular rami" | absolute values are several times too small, and wrong-tooth errors carry only moderately raised uncertainty | in that image the uncertainty was in the top 2% |
| 2.7 | "predicted uncertainty" | adds the definition (predicted scale of the final refinement update, converted to millimetres) | so the correlation is reproducible |

## Failure cases as now described (overlays in `results/manuscript_metrics/`)

1. `cks2ip8g62b7b0yuffrlb7xa1` (ART Plus): ear rods not superimposed; ramus 10.5, condylion 16.5, articulare 20.3 mm
   anterior to the reference, orbitale 14.5 mm. Uncertainty 0.6-1.9 mm, top 2% of the test set.
2. `cl5lg05un01hm074k3dwy9l5q` (ProMax with ProTouch): labrale superius and inferius each 16.6 mm off. The reference
   labels are interchanged in both annotators' files; with the labels exchanged the errors are 0.60 and 0.32 mm.
   It is the only test image in which the reference upper lip lies below the lower lip.
3. `cks2ip8g02asq0yuf59owfht0` and `cks2ip8fq29zp0yuf7cxd3bz2` (ART Plus): molar and second-premolar cusp tips 6-12 mm
   anterior along the occlusal plane; the predicted upper molar lies within 0.2-1.6 mm of the reference upper second premolar.
4. `cl777aklx03ua076whaie06kb` (Rotograph EVO): ear rods over the temporomandibular region; seven landmarks 4-12 mm off.

## For you to decide

- The swapped lip labels in case 2 are an error in the published Aariz annotations. Correcting them would lower the
  Aariz MRE from 1.105 to about 1.097 mm. The manuscript keeps the official annotations and reports the case; say so
  if you prefer the corrected value.
- Case 1 was previously attributed to the "contralateral ramus". The image shows two non-superimposed ear rods and
  predictions about 17 mm anterior to the reference; I described what is visible and did not assert the cause.
- Section 2.1 still contains the placeholder sentence about ethics approval ("Ethics: confirm with your institution ...").
  It must be replaced before submission.
- ISBI 2015 Test1 has two very large sella errors (images 181 and 194: 31.9 and 14.4 mm). They are in the supplement's
  SD for sella (2.811 mm) but are not mentioned in the text.
- Aariz junior and senior annotations are identical or nearly identical for six landmarks (the four molar and premolar
  cusp tips, sella, and two are exactly 0.000 mm apart). The inter-observer figures in 3.2 are therefore not a full
  measure of observer variability for those points.

## Added later on 2026-10-06: GPU verification

- **Released checkpoints reproduce the prediction files** for all four evaluation sets (largest coordinate difference:
  Aariz 0.035 px, ISBI Test1 0.001 px, ISBI Test2 0.000 px, CephAdoAdu 0.000 px; MRE identical to four decimals).
- **Uncertainty on the other datasets.** Spearman rho is 0.61 on Aariz but only 0.14 (ISBI Test1), 0.19 (ISBI Test2)
  and 0.39 (CephAdoAdu). The least confident decile still has the highest MRE on each (1.52, 2.54, 1.63 mm).
  Manuscript: one sentence added to 3.5, the Discussion paragraph now says "On Aariz" and ends with a caution that
  uncertainty-guided review should be validated on the target data, and 2.7 says the analysis was repeated on the
  other evaluation sets. Full table: `results/manuscript_metrics/checkpoint_reproduction_uncertainty.md`.
- **Still running on the Kaggle session (not yet in the manuscript):**
  1. `outputs/ablation_full150` - full model trained with the exact ablation settings (150 epochs, seed 42), to give
     Table 6 a reference row of equal training length. About 4.5 hours.
  2. `outputs/isbi_phase1_seed1` - phase-1 recipe (200 epochs) with seed 1, to check the Table 6 reference row
     (1.188 mm / 84.39%, 1.595 mm / 73.21%) and to give one estimate of seed-to-seed variation. About 6 hours.

## Added 2026-10-06 05:35: matched ablation reference (Table 6)

The full model was retrained on ISBI 2015 with the exact ablation settings (150 epochs, one-cycle, seed 42) so that the
reference row of Table 6 has the same training length as the four variants and can be verified from prediction files
(`results/training_runs/ablation_full150/`). Best validation MRE 1.18 mm at epoch 139.

| Table 6, reference row | Was (phase-1 model, 200 epochs, no prediction file) | Now (150 epochs) |
|---|---|---|
| Test1 MRE / SDR 2 mm | 1.188 mm / 84.39% | 1.180 mm / 85.79% |
| Test2 MRE / SDR 2 mm | 1.595 mm / 73.21% | 1.571 mm / 74.16% |

Other thresholds: Test1 SDR 2.5/3/4 mm = 91.72 / 95.26 / 98.14%; Test2 = 82.16 / 87.84 / 95.16%.

Manuscript edits: Table 6 reference row and footnote; section 2.6 (reference is now the full model trained with the same
150-epoch schedule); section 3.4 (MRE "rose from 1.180 to 12.616 mm"; single refinement update: +0.59 mm and
-20.0 percentage points). The conclusions of the ablation are unchanged; the no-heatmap variant (1.171 mm, 86.18%)
still does not fall below the reference.

**Figure 4 still shows the old reference bars (1.188 and 1.595 mm).** The difference is invisible on its logarithmic
scale, but the figure should be regenerated with 1.180 and 1.571 mm for consistency.


## Added 2026-10-06 07:27: seed replicate on ISBI 2015

The first training phase (200 epochs, one-cycle, max lr 2e-4) was repeated with seed 1 instead of 42
(`results/training_runs/isbi_phase1_seed1/`). Best validation MRE 1.36 mm at epoch 188.

| Run | Test1 MRE / SDR 2 mm | Test2 MRE / SDR 2 mm |
|---|---|---|
| Seed 42, 200 epochs (original phase 1, from the log and the old Table 6) | 1.188 mm / 84.39% | 1.595 mm / 73.21% |
| Seed 42, 150 epochs (matched ablation reference, verified) | 1.180 mm / 85.79% | 1.571 mm / 74.16% |
| Seed 1, 200 epochs (this run, verified) | 1.360 mm / 80.84% | 1.657 mm / 69.00% |

Seed 1, all thresholds (MRE / SDR 2 / 2.5 / 3 / 4 mm): Test1 1.360 mm / 80.84% / 88.42% / 93.23% / 97.12%; Test2 1.657 mm / 69.00% / 78.95% / 86.26% / 94.37%.

What happened in the seed-1 run: the validation error fell to 13 mm by epoch 59, jumped back to about 40 mm at epoch 60
(around the peak learning rate) and only recovered after epoch 95, so the model had fewer effective epochs to converge and
was still improving at the end. One seed is one observation, not an estimate of the spread.

Manuscript edit: one sentence added to the limitations paragraph stating this run-to-run difference and that differences
of that size between configurations (for example full model vs no heatmap head) should not be interpreted.

Not changed, for you to consider:
- The final ISBI model (three phases, 528 epochs) was not re-trained with another seed, so its seed sensitivity is unknown;
  phases 2 and 3 may well close most of this gap.
- Section 3.4 says removing the heatmap head "did not reduce accuracy" (1.171 vs 1.180 mm). That remains true, and the
  new limitation sentence already says such a difference is within run-to-run variation.


## Added 2026-10-06: Figure 4 regenerated

`Figure4_ablation.tif` was redrawn with the new reference bars (Full model: 1.180 mm on Test1, 1.571 mm on Test2) in the same size, format and style as before (1650 x 960 px, 300 dpi, LZW TIFF) and replaced in the submission zip. The other eight bars are unchanged. The old figure is in `updated_manuscript/previous_version/`; the script is `make_figure4.py`. The Fig. 4 legend in the manuscript needed no change.


## Added 2026-10-06 20:25: three-phase seed replicates (interrupted; manuscript not changed)

**The Kaggle session ended about 3 h 50 min after it started, long before the 12-hour limit, so the three-phase runs
did not complete.** The last successful check was at 15:41 UTC; by 16:02 UTC the session no longer existed (the server
returns 404). Nothing in the runs had failed: both were training normally. A session ending this early is usually
Kaggle's idle shutdown (the notebook tab closed or left without interaction), not the 12-hour cap.

## What was running

Two full three-phase runs (200 + 200 + 128 epochs), one per GPU, with mixed-precision arithmetic in the backbone only
(transformers, coordinate heads, losses and metrics in full precision) to bring the 528 epochs from about 16 hours to
about 9: seed 42 as a control for the precision change, and seed 2 as a new seed.

## What was saved

| Run | Stage reached | Test1 MRE / SDR 2 mm | Test2 MRE / SDR 2 mm | Source |
|---|---|---|---|---|
| Seed 42, mixed precision | phase 1 complete; phase 2 at epoch 2 of 200 | 1.166 mm / 85.37% | 1.526 mm / 74.42% | prediction files (saved) |
| Seed 2, mixed precision | phase 1 at epoch 194 of 200 | 1.156 mm / 86.1% (best epoch, 172) | not available | training log only; Test1 is the validation set |

Seed 42 phase 1, all thresholds: Test1 SDR 2 / 2.5 / 3 / 4 mm = 85.37 / 91.65 / 95.40 / 98.11%; Test2 = 74.42 / 82.47 / 88.47 / 94.47%.

No phase-2 or phase-3 result exists, so there is **no new three-phase result** to set against the published
1.124 mm / 87.12% (Test1) and 1.463 mm / 74.74% (Test2).

## What the phase-1 results show

| Phase-1 run (200 epochs) | Precision | Test1 MRE | Test1 SDR 2 mm | Test2 MRE |
|---|---|---:|---:|---:|
| Seed 42, original | full | 1.188 mm | 84.39% | 1.595 mm |
| Seed 42, control | mixed (backbone) | 1.166 mm | 85.37% | 1.526 mm |
| Seed 2 | mixed (backbone) | 1.156 mm | 86.1% | - |
| Seed 1 (run of 2026-10-05/06) | full | 1.360 mm | 80.84% | 1.657 mm |

- Mixed precision did not hurt: with the same seed the result is 1.166 mm against 1.188 mm. The two runs are not
  bit-identical, so this is itself an example of run-to-run variation of about 0.02 mm.
- Seed 2 trained smoothly and reached the same level as seed 42. Three of the four phase-1 runs lie within
  1.156-1.188 mm; seed 1, which diverged near the peak learning rate, is the outlier at 1.360 mm.
- So the picture is: usually a spread of a few hundredths of a millimetre, with an occasional unstable run that ends
  about 0.2 mm worse after phase 1. Whether phases 2 and 3 repair such a run is still unknown.

## Manuscript

**I did not change the manuscript or the supplement this time.** Both were edited at 10:16 on 2026-10-06, after my last
change: the limitations sentence now cites a new Table S7 in the supplement, which lists the phase-1 runs. Rather than
overwrite that wording, here is what could be added if you want the two new runs included.

Two extra rows for Table S7:

| Run | Epochs | Seed | Test1 MRE (mm) | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE (mm) | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|
| Phase 1 repeated, mixed precision in the backbone | 200 | 42 | 1.166 | 85.37 / 91.65 / 95.40 / 98.11 | 1.526 | 74.42 / 82.47 / 88.47 / 94.47 |
| Seed replicate of phase 1, mixed precision in the backbone* | 200 | 2 | 1.156 | 86.1 / 92.1 / 95.3 / 98.1 | - | - |

*From the training log at the best epoch (172); the run was interrupted at epoch 194 and Test2 was not evaluated.

Replacement for the limitations sentence:

> Run-to-run variation was not negligible (Table S7): when the first 200-epoch training phase on ISBI 2015 was repeated
> with two other random seeds, the Test1 MRE was 1.156 mm in one run and 1.360 mm in the other, in which training
> temporarily diverged near the peak learning rate, compared with 1.188 mm originally, so differences of this size
> between configurations, such as that between the full model and the variant without the heatmap head, should not be
> interpreted.

Whether to include them is a judgement call: they make the picture fairer (the 1.360 mm run looks like an outlier, not
the typical spread), but the seed-2 figure comes from a log, not from saved predictions, and both runs used mixed
precision, which the Methods would then have to mention.

## To finish the three-phase replicates

It needs one uninterrupted session of about 9.5 hours. What makes that survive:

- Start it as a **committed run** ("Save Version" -> "Save & Run All") instead of an interactive session. Committed
  runs do not depend on a browser tab and keep `/kaggle/working` as output afterwards. That requires the commands to
  be cells in the notebook; I can write that notebook for you.
- Or keep an interactive session's tab open and in the foreground for the whole time.

Scripts are ready: `train_fast.py` (seed and backbone mixed precision) and `job3p.sh` (three phases with inference
after each) can be recreated in minutes in a new session.

Saved files: `results/training_runs_3phase/`.


## Added 2026-10-08: three-phase seed replicates on ISBI 2015 - complete (manuscript not changed; proposals below)

Both runs finished all three phases (200 + 200 + 128 epochs). The complete recipe was repeated twice with
mixed-precision arithmetic in the backbone: once with the published seed (42) and once with a new seed (2).

## Final results (three phases)

| Model | Seed | Precision | Test1 MRE +/- SD (mm) | Test1 MRE 95% CI | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE +/- SD (mm) | Test2 MRE 95% CI | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|---|---|
| Published model | 42 | full | 1.124 +/- 1.076 | 1.082-1.169 | 87.12 / 92.53 / 96.11 / 98.39 | 1.463 +/- 1.385 | 1.419-1.508 | 74.74 / 83.47 / 88.84 / 94.63 |
| Replicate | 42 | mixed (backbone) | 1.102 +/- 0.942 | 1.063-1.145 | 87.40 / 92.21 / 95.68 / 98.35 | 1.426 +/- 1.280 | 1.386-1.467 | 76.74 / 83.21 / 88.89 / 95.00 |
| Replicate | 2 | mixed (backbone) | 1.122 +/- 0.943 | 1.081-1.165 | 87.05 / 92.53 / 95.61 / 98.32 | 1.462 +/- 1.467 | 1.406-1.532 | 75.42 / 83.00 / 88.74 / 94.95 |

Across the three complete runs: Test1 MRE 1.102-1.124 mm and SDR at 2 mm 87.05-87.40%; Test2 MRE 1.426-1.463 mm and
SDR at 2 mm 74.74-76.74%. 95% CIs: percentile bootstrap, 10,000 image-level resamples.

## By phase

| Seed | Phase | Epochs | Best validation MRE (mm) | Test1 MRE (mm) / SDR 2 mm (%) | Test2 MRE (mm) / SDR 2 mm (%) |
|---|---|---|---|---|---|
| 42 | 1 | 200 | 1.171 | 1.171 / 85.75 | 1.532 / 75.11 |
| 42 | 2 | 200 | 1.102 | 1.102 / 87.40 | 1.426 / 76.74 |
| 42 | 3 | 128 | 1.102 (no improvement; best phase-3 epoch 1.121) | 1.102 / 87.40 | 1.426 / 76.74 |
| 2 | 1 | 200 | 1.171 | 1.171 / 85.47 | 1.556 / 74.47 |
| 2 | 2 | 200 | 1.122 | 1.122 / 86.91 | 1.482 / 75.63 |
| 2 | 3 | 128 | 1.122 | 1.122 / 87.05 | 1.462 / 75.42 |

For seed 42 the third phase never beat the phase-2 checkpoint, so its final model is the phase-2 one (the predictions
are identical). For seed 2 the third phase produced a marginally better checkpoint. This matches the manuscript's
remark about diminishing returns from further fine-tuning.

## Paired differences in per-image error (same images)

| Comparison | Test1: mean difference in mm (95% CI) | Test2: mean difference in mm (95% CI) |
|---|---|---|
| Published - seed 42 replicate | +0.022 (+0.005 to +0.042) | +0.037 (+0.014 to +0.066) |
| Published - seed 2 replicate | +0.002 (-0.016 to +0.024) | +0.001 (-0.055 to +0.036) |
| Seed 42 replicate - seed 2 replicate | -0.019 (-0.033 to -0.007) | -0.037 (-0.094 to +0.001) |

## What this shows

- **The published three-phase result is reproducible.** The new seed gives 1.122 mm / 1.462 mm against the published
  1.124 mm / 1.463 mm: differences of 0.002 and 0.001 mm.
- **Run-to-run spread of the complete recipe is about 0.02 mm on Test1 and 0.04 mm on Test2**, i.e. well inside the
  bootstrap confidence intervals of each run.
- **The same-seed replicate is not identical to the published model** (1.102 vs 1.124 mm). It differs in precision
  mode and hardware, and it was resumed from saved state several times; it is slightly better, not worse, so mixed
  precision did not harm accuracy.
- **The unstable phase-1 run with seed 1 (1.360 mm) was not typical.** Phase 1 gave 1.171 mm for both seeds here and
  1.188 mm originally. Whether phases 2 and 3 would have repaired the seed-1 run was not tested.

## Practical notes on how the runs were made

- Mixed precision (16-bit) in the convolutional backbone only; transformer encoders, coordinate heads, losses and
  metrics in 32-bit. About 63 s per epoch instead of about 110 s.
- The Kaggle sessions ended early four times. Training state was saved every epoch and uploaded to Hugging Face every
  30 minutes, and each run continued from its last completed epoch on a new session (phase 1 at epochs 53/55, phase 2
  at epochs 138/158). A resumed run is not bit-identical to an uninterrupted one.

## Proposed additions for the manuscript (not applied - you edit these files)

Table S7 currently lists first-phase runs only. Suggested: retitle it "Additional training runs of the full model on
ISBI 2015" and add these rows (and drop the footnote sentence "The final ISBI 2015 model (three phases, 528 epochs) was
not repeated with another seed"):

| Run | Epochs | Seed | Test1 MRE (mm) | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE (mm) | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|
| Final model (three phases), as reported | 528 | 42 | 1.124 | 87.12 / 92.53 / 96.11 / 98.39 | 1.463 | 74.74 / 83.47 / 88.84 / 94.63 |
| Three-phase replicate* | 528 | 42 | 1.102 | 87.40 / 92.21 / 95.68 / 98.35 | 1.426 | 76.74 / 83.21 / 88.89 / 95.00 |
| Three-phase replicate* | 528 | 2 | 1.122 | 87.05 / 92.53 / 95.61 / 98.32 | 1.462 | 75.42 / 83.00 / 88.74 / 94.95 |
| Phase 1 of the replicate* | 200 | 42 | 1.171 | 85.75 / 91.72 / 95.05 / 97.93 | 1.532 | 75.11 / 82.47 / 88.21 / 94.95 |
| Phase 1 of the replicate* | 200 | 2 | 1.171 | 85.47 / 91.75 / 95.51 / 98.14 | 1.556 | 74.47 / 82.47 / 88.05 / 94.84 |

*Trained with mixed-precision arithmetic in the backbone.

Replacement for the limitations sentences (from "Fifth, each configuration was trained once ..." up to "... should not
be interpreted."):

> Fifth, the Aariz and CephAdoAdu models and the ablation variants were each trained once, so their confidence
> intervals reflect sampling of the evaluation images only, and the ablation variants were trained for fewer epochs
> than the final models. For ISBI 2015, the complete three-phase training was repeated twice, with the original and
> with a different random seed (Table S7): the Test1 MRE was 1.102 and 1.122 mm, against 1.124 mm for the reported
> model, and the Test2 MRE 1.426 and 1.462 mm against 1.463 mm, so run-to-run variation of the full recipe was about
> 0.02-0.04 mm. Single 200-epoch runs varied more: one repetition of the first phase became temporarily unstable near
> the peak learning rate and ended at 1.360 mm instead of 1.17-1.19 mm, so differences of a few hundredths of a
> millimetre between ablation variants, such as that between the full model and the variant without the heatmap head,
> should not be interpreted.

If you adopt this, add one clause to section 2.5 or to the Table S7 footnote: "the replicate runs used mixed-precision
arithmetic in the convolutional backbone to shorten training".

## Where everything is

- Hugging Face, `main` branch of `emad2001/DeLR-Cephalometric-ConvNeXtV2`: `checkpoints/ISBI2015_seed_replicates/`
  (logs, predictions for every phase, the two final checkpoints, `train_fast.py`, `job3p.sh`).
- Local: `results/training_runs_3phase/` (logs, metrics, predictions, `final_metrics_with_ci.json`).
- The work branch `seedrep-wip-27` on Hugging Face holds the last rolling training state and is no longer needed.
- The earlier interrupted attempt is in `results/training_runs_3phase_interrupted_2026-10-06/`.
