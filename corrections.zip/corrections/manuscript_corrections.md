# Manuscript corrections (items 3-6)

Every number below is taken from `manuscript_metrics.md`. Search the manuscript
for the "find" values and replace them; the paragraphs can be pasted as they are.

## 3. CephAdoAdu millimetre convention

Find and replace everywhere (abstract, results text, tables, figure captions, conclusion):

| Quantity (CephAdoAdu, all 300 images) | Old value (0.1 mm per original pixel) | Correct value (CeLDA convention) |
|---|---:|---:|
| MRE | 1.045 mm (also written 1.05) | **1.010 mm** (95 % CI 0.971-1.050) |
| SDR @ 2.0 mm | 87.53 % | **89.67 %** (88.40-90.93) |
| SDR @ 2.5 mm | 92.37 % | **94.00 %** (93.03-94.90) |
| SDR @ 3.0 mm | 95.27 % | **96.27 %** (95.50-97.00) |
| SDR @ 4.0 mm | 97.63 % | **98.53 %** (98.07-98.97) |
| MRE in pixels | 10.45 px | delete (a single pixel value is not meaningful: image sizes differ) |

Add to Methods (evaluation metrics):

> For CephAdoAdu, which provides no physical pixel spacing and whose images
> range from about 600 to 3550 pixels on the longest side, radial errors were
> converted to millimetres following the dataset's reference implementation
> (Wu et al., 2024): landmark coordinates were mapped to the image rescaled to a
> longest side of 2048 pixels and a spacing of 0.1 mm per pixel was applied.
> For Aariz the per-image pixel size supplied with the dataset was used, and
> for ISBI 2015 the official value of 0.1 mm per pixel.

If the manuscript mentions model selection: the CephAdoAdu checkpoint was
selected on a 10 % hold-out of the training part using the uncorrected
conversion. This affects only the units of the selection criterion, not the
predictions, so no retraining is needed; no sentence is required unless you
quote validation-curve values, in which case label them "0.1 mm per original
pixel (training-time monitor)".

## 4. Which CephAdoAdu images are evaluated

Replace "test set" / "300 test images" for CephAdoAdu with the wording below.

Dataset description (Methods):

> CephAdoAdu comprises 1000 lateral cephalograms (500 adolescents, 500 adults)
> annotated with 10 landmarks and divided by its authors into training (400),
> validation (300) and test (300) parts, each balanced by age group. The public
> release contains the training and validation parts. We trained on the
> training part, holding out 10 % of it for model selection, and report results
> on the 300 validation images (150 adolescents, 150 adults), which were never
> used for training or model selection.

Wherever your results are compared with CeLDA or other published CephAdoAdu numbers, add:

> Published results for CephAdoAdu refer to its test part, which is not part of
> the public release; our results are computed on the validation part with the
> same metric definition, so the comparison is indicative rather than
> like-for-like.

Table captions / column headers: "CephAdoAdu (validation part, n = 300)".

(Check the first paragraph against the dataset paper before submission: the
1000 / 400 / 300 / 300 figures are from Wu et al., and "the public release
contains the training and validation parts" is from your statement that the 300
images are the validation part.)

## 5. Aariz: test, not validation

| Quantity (Aariz, 26 landmarks) | Value in README/log (validation) | Correct test-set value |
|---|---:|---:|
| MRE | 1.073 mm (1.075 in the last epochs) | **1.105 +/- 1.313 mm** (95 % CI 1.013-1.202) |
| SDR @ 2.0 mm | 87.0 % | **86.85 %** (84.79-88.77) |
| SDR @ 2.5 mm | 92.1 % | **90.95 %** (89.26-92.51) |
| SDR @ 3.0 mm | 94.8 % | **93.90 %** (92.51-95.18) |
| SDR @ 4.0 mm | 97.2 % | **96.74 %** (95.74-97.64) |

Add to the Aariz dataset description if not already there:

> We used the 26 skeletal, dental and soft-tissue-profile landmarks retained by
> our loader (the first 26 of the 29 annotated landmarks; soft-tissue nasion,
> soft-tissue pogonion and subnasale were excluded), with the mean of the
> junior and senior annotations as ground truth.

Any comparison with methods evaluated on all 29 Aariz landmarks should say so.

## 6. Adolescent vs adult (Table 5 and its two paragraphs)

Replace Table 5 with:

| Metric | Adolescent (n = 150) | Adult (n = 150) | Difference, adolescent - adult (95 % CI) |
|---|---:|---:|---:|
| MRE +/- SD (mm) | 0.972 +/- 0.983 | 1.049 +/- 0.892 | -0.077 (-0.155 to +0.003) |
| MRE 95 % CI (mm) | 0.911-1.037 | 1.004-1.097 | |
| SDR @ 2.0 mm (%) | 91.27 (89.53-92.93) | 88.07 (86.20-89.87) | +3.20 (+0.67 to +5.80) |
| SDR @ 2.5 mm (%) | 94.67 (93.20-96.00) | 93.33 (92.00-94.53) | +1.33 (-0.53 to +3.20) |
| SDR @ 3.0 mm (%) | 96.20 (95.07-97.27) | 96.33 (95.40-97.27) | -0.13 (-1.60 to +1.33) |
| SDR @ 4.0 mm (%) | 98.40 (97.67-99.00) | 98.67 (98.07-99.20) | -0.27 (-1.13 to +0.60) |

Caption: "Accuracy by age group on the CephAdoAdu validation part. 95 %
confidence intervals from a 10,000-resample image-level percentile bootstrap.
Per-image mean radial error: Mann-Whitney U = 8409, p < 0.001 (rank-biserial
r = -0.25); Welch t-test p = 0.058; Cohen's d = -0.22."

Results and Discussion paragraphs: use the ones in
`cephadoadu_age_group_text.md` (already written for these numbers and for the
validation-part wording).

Statements that must not remain anywhere in the manuscript:

- that the model is "significantly" or "substantially" more accurate in
  adolescents overall (the MRE difference is 0.08 mm and its CI includes zero);
- an adolescent-adult MRE gap of about 0.25 mm, adolescent 0.923 mm, adult
  1.168 mm, or SDR@2 mm of 84.00 % for adults (all from the uncorrected conversion);
- five landmarks differing between groups (it is three: A point, ANS, porion).

What can be said: accuracy is comparable across age groups; adolescents have a
3-point advantage only at the strictest 2 mm threshold; the difference is
confined to A point, ANS and porion.
