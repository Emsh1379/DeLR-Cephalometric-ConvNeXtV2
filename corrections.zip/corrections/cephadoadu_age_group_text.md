# CephAdoAdu adolescent vs adult - draft manuscript text

All numbers come from `manuscript_metrics.md` / `summary.json` in this folder
(the 300 images of the official CephAdoAdu validation part - 150 adolescent, 150 adult,
10 landmarks - which were never used for training or model selection; 95 % CIs
from a 10,000-resample image-level percentile bootstrap).

Millimetre conversion: the dataset ships no physical pixel spacing and image
sizes range from about 600 to 3550 px on the longest side. We therefore follow
the official CephAdoAdu / CeLDA evaluation code (Wu et al., MICCAI 2024;
`code/test.py`, `infer_util.mappping_back`): coordinates are mapped to the image
rescaled so that its longest side is 2048 px and distances are multiplied by
0.1 mm. Numbers obtained with 0.1 mm per *original* pixel (what `train.py` /
`infer.py` log, e.g. the 1.045 mm in the README) are listed in the sensitivity
rows of Table 5 and should not be compared with published CephAdoAdu results.

## Methods sentence (evaluation protocol)

For CephAdoAdu, radial errors were converted to millimetres with the protocol
of the dataset's reference implementation: landmark coordinates were mapped to
the image rescaled to a longest side of 2048 pixels and a spacing of 0.1 mm per
pixel was applied.

## Results paragraph

On the 300 held-out CephAdoAdu images (the official validation part) the model reached an overall MRE of 1.010 mm
(95 % CI 0.971-1.050) with an SDR of 89.67 % (88.40-90.93) at 2 mm and 98.53 %
(98.07-98.97) at 4 mm. Accuracy was slightly higher in adolescents than in
adults (Table 5): the MRE was 0.972 +/- 0.983 mm (95 % CI 0.911-1.037) versus
1.049 +/- 0.892 mm (1.004-1.097), a difference of -0.077 mm whose 95 % CI
(-0.155 to +0.003) includes zero. The distribution of per-image mean radial
error was nevertheless shifted towards lower values in adolescents
(Mann-Whitney U = 8409, p < 0.001; rank-biserial r = -0.25), with a small
effect size (Cohen's d = -0.22; Welch t-test p = 0.058). The 2 mm SDR was
91.27 % (89.53-92.93) in adolescents and 88.07 % (86.20-89.87) in adults
(difference +3.20 percentage points, 95 % CI +0.67 to +5.80); from 2.5 mm
upwards the two groups were indistinguishable (differences of +1.33, -0.13 and
-0.27 points at 2.5, 3 and 4 mm, all CIs including zero). At the landmark
level, the difference was significant after Holm correction for three of the
ten landmarks, all in favour of adolescents: A point (0.870 vs 1.224 mm),
ANS (0.749 vs 1.030 mm) and porion (1.304 vs 1.764 mm). The remaining seven
landmarks showed no significant group difference.

## Discussion paragraph

Performance was largely consistent across age groups. The adolescent-adult gap
in MRE was below 0.1 mm with a confidence interval that includes zero, and the
success detection rates of the two groups coincided from the 2.5 mm threshold
upwards; the only aggregate difference was a 3-point advantage for adolescents
at the strictest 2 mm threshold. The age effect was therefore small and was
confined to three landmarks - A point, ANS and porion - while the dental
landmarks (UI, UIA, LI, LIA), orbitale, subnasale and pogonion were localised
equally well in both groups. Both groups are equally represented in the
official training split (200 images each), so this residual difference is
unlikely to be a sample-size artefact; whether it reflects image appearance or
annotation variability at those three landmarks in adults cannot be determined
from the present data, as no inter-observer reference is available for
CephAdoAdu. Two limitations apply: millimetre values rest on the dataset's
nominal conversion (longest side 2048 px at 0.1 mm/px) rather than on a
calibrated per-image spacing, and the evaluation uses the official validation
part of the public release rather than the test set reported by Wu et al.,
so absolute values are not directly comparable with their published test results.
