# DeLR manuscript results - everything in one file

Generated 2026-10-05 from the saved test predictions in the repository
(`checkpoints/*/test*_predictions.json`) and the ground-truth annotations of
Aariz, ISBI 2015 and CephAdoAdu, using `evaluate_manuscript_metrics.py`.

Contents
1. Key numbers
2. Full report: Table 2, Table 5, per-landmark supplement tables
3. Draft manuscript text for the adolescent vs adult comparison
4. Manuscript corrections (items 3-6)
5. How the numbers were verified
6. Open points
7. Per-device accuracy, failure cases and rank correlations
8. Predicted uncertainty and failure cases
9. Changes made to the manuscript

---

# Part 1 - Key numbers

| Dataset / split | N | Landmarks | MRE +/- SD (mm) | MRE 95% CI | SDR@2 mm | SDR@2.5 mm | SDR@3 mm | SDR@4 mm |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Aariz test | 150 | 26 | 1.105 +/- 1.313 | 1.013-1.202 | 86.85 | 90.95 | 93.90 | 96.74 |
| ISBI 2015 Test1 | 150 | 19 | 1.124 +/- 1.076 | 1.082-1.169 | 87.12 | 92.53 | 96.11 | 98.39 |
| ISBI 2015 Test2 | 100 | 19 | 1.463 +/- 1.385 | 1.419-1.508 | 74.74 | 83.47 | 88.84 | 94.63 |
| CephAdoAdu validation part, all | 300 | 10 | 1.010 +/- 0.939 | 0.971-1.050 | 89.67 | 94.00 | 96.27 | 98.53 |
| CephAdoAdu adolescent | 150 | 10 | 0.972 +/- 0.983 | 0.911-1.037 | 91.27 | 94.67 | 96.20 | 98.40 |
| CephAdoAdu adult | 150 | 10 | 1.049 +/- 0.892 | 1.004-1.097 | 88.07 | 93.33 | 96.33 | 98.67 |

- Confidence intervals: percentile bootstrap, 10,000 resamples at image level. SDR intervals are in Part 2.
- Adolescent minus adult: MRE -0.077 mm (95% CI -0.155 to +0.003); SDR@2 mm +3.20 points (+0.67 to +5.80); no difference from 2.5 mm upwards. Three landmarks differ after Holm correction (A point, ANS, porion), all favouring adolescents.
- CephAdoAdu millimetres use the official CeLDA convention (longest image side rescaled to 2048 px, 0.1 mm/px). With 0.1 mm per original pixel the overall MRE would read 1.045 mm; that value is not comparable with published results.
- The CephAdoAdu images evaluated are the 300 of the official validation part (never used for training or model selection).
- Aariz values are for the test set; the 1.073 mm in the old README was a validation figure.

---

# Part 2 - Full report
95 % confidence intervals: percentile bootstrap, 10000 resamples at the image level, seed 2025. SD is the standard deviation of the radial error over all landmark instances. Ground truth is the junior/senior mean for Aariz and ISBI 2015. Pixel size: per image from cephalogram_machine_mappings.csv (Aariz), 0.1 mm (ISBI 2015), CephAdoAdu conversion = 'celda' (see Table 5 sensitivity rows).

## Table 2 - overall accuracy with 95 % confidence intervals

| Dataset / split | N images | Landmarks | MRE +/- SD (mm) | MRE 95% CI (mm) | SDR@2.0 mm % (95% CI) | SDR@2.5 mm % (95% CI) | SDR@3.0 mm % (95% CI) | SDR@4.0 mm % (95% CI) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Aariz (test) | 150 | 26 | 1.105 +/- 1.313 | 1.013-1.202 | 86.85 (84.79-88.77) | 90.95 (89.26-92.51) | 93.90 (92.51-95.18) | 96.74 (95.74-97.64) |
| ISBI 2015 Test1 | 150 | 19 | 1.124 +/- 1.076 | 1.082-1.169 | 87.12 (85.72-88.49) | 92.53 (91.33-93.61) | 96.11 (95.23-96.91) | 98.39 (97.86-98.88) |
| ISBI 2015 Test2 | 100 | 19 | 1.463 +/- 1.385 | 1.419-1.508 | 74.74 (73.26-76.21) | 83.47 (82.26-84.63) | 88.84 (87.84-89.79) | 94.63 (93.89-95.37) |
| CephAdoAdu (official validation split, all) | 300 | 10 | 1.010 +/- 0.939 | 0.971-1.050 | 89.67 (88.40-90.93) | 94.00 (93.03-94.90) | 96.27 (95.50-97.00) | 98.53 (98.07-98.97) |
| CephAdoAdu - adolescent | 150 | 10 | 0.972 +/- 0.983 | 0.911-1.037 | 91.27 (89.53-92.93) | 94.67 (93.20-96.00) | 96.20 (95.07-97.27) | 98.40 (97.67-99.00) |
| CephAdoAdu - adult | 150 | 10 | 1.049 +/- 0.892 | 1.004-1.097 | 88.07 (86.20-89.87) | 93.33 (92.00-94.53) | 96.33 (95.40-97.27) | 98.67 (98.07-99.20) |

## Table 5 - CephAdoAdu: adolescent vs adult

| Metric | Adolescent (n = 150) | Adult (n = 150) | Difference Ado - Adu (95% CI) |
|---|---:|---:|---:|
| MRE +/- SD (mm) | 0.972 +/- 0.983 | 1.049 +/- 0.892 | -0.077 (-0.155 to +0.003) |
| MRE 95% CI (mm) | 0.911-1.037 | 1.004-1.097 | |
| Median radial error (mm) | 0.711 | 0.802 | |
| SDR@2.0 mm (%) | 91.27 (89.53-92.93) | 88.07 (86.20-89.87) | +3.20 (+0.67 to +5.80) |
| SDR@2.5 mm (%) | 94.67 (93.20-96.00) | 93.33 (92.00-94.53) | +1.33 (-0.53 to +3.20) |
| SDR@3.0 mm (%) | 96.20 (95.07-97.27) | 96.33 (95.40-97.27) | -0.13 (-1.60 to +1.33) |
| SDR@4.0 mm (%) | 98.40 (97.67-99.00) | 98.67 (98.07-99.20) | -0.27 (-1.13 to +0.60) |

Image-level comparison of per-image mean radial error: Mann-Whitney U = 8409.0, p = 0.0001562 (rank-biserial r = -0.253); Welch t = -1.907, p = 0.05755; Cohen's d = -0.220.

| # | Landmark | Adolescent MRE +/- SD (mm) | Adult MRE +/- SD (mm) | Diff (mm) | Adolescent SDR@2 (%) | Adult SDR@2 (%) | p (Mann-Whitney) | p (Holm) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | A | 0.870 +/- 0.617 | 1.224 +/- 0.760 | -0.355 | 96.00 | 84.67 | 7.802e-06 | 7.802e-05 |
| 2 | ANS | 0.749 +/- 0.441 | 1.030 +/- 0.806 | -0.281 | 99.33 | 92.00 | 0.001747 | 0.01398 |
| 3 | UI | 0.567 +/- 0.737 | 0.437 +/- 0.394 | +0.130 | 98.00 | 99.33 | 0.02418 | 0.1693 |
| 4 | UIA | 1.264 +/- 1.140 | 1.301 +/- 0.824 | -0.037 | 86.67 | 82.00 | 0.07925 | 0.4755 |
| 5 | Or | 1.165 +/- 1.237 | 1.171 +/- 0.821 | -0.006 | 88.67 | 86.67 | 0.2301 | 1 |
| 6 | P | 1.304 +/- 0.999 | 1.764 +/- 1.240 | -0.459 | 85.33 | 69.33 | 0.0001983 | 0.001785 |
| 7 | LI | 0.596 +/- 0.558 | 0.601 +/- 0.517 | -0.004 | 97.33 | 96.67 | 0.9147 | 1 |
| 8 | LIA | 1.498 +/- 1.195 | 1.290 +/- 0.870 | +0.208 | 76.67 | 84.00 | 0.3402 | 1 |
| 9 | Sn | 0.568 +/- 0.424 | 0.582 +/- 0.502 | -0.014 | 98.67 | 99.33 | 0.7089 | 1 |
| 10 | Pog | 1.137 +/- 1.334 | 1.091 +/- 0.989 | +0.046 | 86.00 | 86.67 | 0.7691 | 1 |

Sensitivity to the pixel-to-mm conversion (point estimates):

| Conversion | Group | MRE (mm) | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---|---|---:|---:|---:|---:|---:|
| CeLDA: longest side -> 2048 px, 0.1 mm/px | all | 1.010 | 89.67 | 94.00 | 96.27 | 98.53 |
| CeLDA: longest side -> 2048 px, 0.1 mm/px | adolescent | 0.972 | 91.27 | 94.67 | 96.20 | 98.40 |
| CeLDA: longest side -> 2048 px, 0.1 mm/px | adult | 1.049 | 88.07 | 93.33 | 96.33 | 98.67 |
| 0.1 mm per original pixel | all | 1.045 | 87.53 | 92.37 | 95.27 | 97.63 |
| 0.1 mm per original pixel | adolescent | 0.923 | 91.07 | 94.40 | 96.47 | 98.13 |
| 0.1 mm per original pixel | adult | 1.168 | 84.00 | 90.33 | 94.07 | 97.13 |

## Supplementary per-landmark tables

### Aariz (test) - per-landmark results (N = 150 images)

| # | Landmark | MRE +/- SD (mm) | MRE 95% CI | Median (mm) | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | A-point | 0.874 +/- 0.674 | 0.768-0.983 | 0.691 | 93.33 | 96.00 | 98.00 | 100.00 |
| 2 | Anterior Nasal Spine | 1.214 +/- 1.123 | 1.040-1.395 | 0.836 | 84.67 | 89.33 | 92.00 | 95.33 |
| 3 | B-point | 0.834 +/- 0.676 | 0.729-0.939 | 0.649 | 94.00 | 96.67 | 98.67 | 100.00 |
| 4 | Menton | 0.486 +/- 0.424 | 0.420-0.557 | 0.343 | 98.67 | 100.00 | 100.00 | 100.00 |
| 5 | Nasion | 0.859 +/- 0.956 | 0.717-1.018 | 0.579 | 94.00 | 94.00 | 95.33 | 98.67 |
| 6 | Orbitale | 1.292 +/- 1.448 | 1.087-1.542 | 0.914 | 83.33 | 87.33 | 92.00 | 98.00 |
| 7 | Pogonion | 0.553 +/- 0.462 | 0.482-0.630 | 0.417 | 98.67 | 99.33 | 99.33 | 100.00 |
| 8 | Posterior Nasal Spine | 1.412 +/- 1.364 | 1.211-1.647 | 1.064 | 82.00 | 90.00 | 92.67 | 95.33 |
| 9 | Pronasale | 0.791 +/- 0.874 | 0.668-0.947 | 0.606 | 96.67 | 97.33 | 98.67 | 99.33 |
| 10 | Ramus | 2.094 +/- 1.941 | 1.789-2.412 | 1.555 | 63.33 | 70.00 | 79.33 | 86.00 |
| 11 | Sella | 0.631 +/- 0.431 | 0.564-0.702 | 0.555 | 99.33 | 99.33 | 100.00 | 100.00 |
| 12 | Articulare | 1.577 +/- 2.185 | 1.269-1.954 | 0.978 | 79.33 | 83.33 | 86.67 | 92.67 |
| 13 | Condylion | 2.000 +/- 1.834 | 1.720-2.305 | 1.656 | 63.33 | 70.67 | 78.00 | 89.33 |
| 14 | Gnathion | 0.414 +/- 0.351 | 0.360-0.473 | 0.303 | 99.33 | 100.00 | 100.00 | 100.00 |
| 15 | Gonion | 1.473 +/- 1.377 | 1.265-1.696 | 1.001 | 76.00 | 83.33 | 87.33 | 92.67 |
| 16 | Porion | 1.552 +/- 1.461 | 1.329-1.792 | 1.161 | 75.33 | 82.67 | 87.33 | 92.00 |
| 17 | Lower 2nd PM Cusp Tip | 1.277 +/- 1.564 | 1.048-1.551 | 0.921 | 86.67 | 91.33 | 95.33 | 96.00 |
| 18 | Lower Incisor Tip | 0.726 +/- 0.517 | 0.645-0.810 | 0.585 | 96.67 | 99.33 | 100.00 | 100.00 |
| 19 | Lower Molar Cusp Tip | 1.058 +/- 1.284 | 0.870-1.281 | 0.787 | 90.67 | 94.00 | 95.33 | 96.67 |
| 20 | Upper 2nd PM Cusp Tip | 1.336 +/- 1.453 | 1.115-1.582 | 0.815 | 81.33 | 86.00 | 89.33 | 94.00 |
| 21 | Upper Incisor Apex | 1.154 +/- 0.864 | 1.023-1.298 | 0.942 | 83.33 | 92.00 | 96.00 | 98.67 |
| 22 | Upper Incisor Tip | 0.577 +/- 0.581 | 0.489-0.674 | 0.415 | 97.33 | 98.00 | 98.67 | 100.00 |
| 23 | Upper Molar Cusp Tip | 1.321 +/- 1.599 | 1.079-1.586 | 0.775 | 82.00 | 88.00 | 92.67 | 95.33 |
| 24 | Lower Incisor Apex | 1.390 +/- 0.974 | 1.240-1.546 | 1.199 | 75.33 | 86.67 | 93.33 | 98.67 |
| 25 | Labrale inferius | 1.097 +/- 1.639 | 0.870-1.389 | 0.691 | 86.00 | 92.00 | 96.67 | 97.33 |
| 26 | Labrale superius | 0.742 +/- 1.406 | 0.573-0.994 | 0.493 | 97.33 | 98.00 | 98.67 | 99.33 |

### ISBI 2015 Test1 - per-landmark results (N = 150 images)

| # | Landmark | MRE +/- SD (mm) | MRE 95% CI | Median (mm) | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | Sella | 0.779 +/- 2.811 | 0.457-1.305 | 0.454 | 98.67 | 98.67 | 98.67 | 98.67 |
| 2 | Nasion | 1.232 +/- 1.023 | 1.076-1.401 | 1.013 | 83.33 | 90.67 | 94.00 | 95.33 |
| 3 | Orbitale | 1.284 +/- 0.836 | 1.152-1.420 | 1.114 | 86.00 | 92.67 | 96.67 | 98.67 |
| 4 | Porion | 1.820 +/- 1.156 | 1.640-2.010 | 1.688 | 62.67 | 75.33 | 84.00 | 94.00 |
| 5 | Subspinale (A point) | 1.661 +/- 0.997 | 1.504-1.823 | 1.465 | 70.00 | 82.00 | 92.00 | 98.00 |
| 6 | Supramentale (B point) | 1.121 +/- 0.735 | 1.008-1.242 | 1.042 | 88.00 | 95.33 | 98.00 | 100.00 |
| 7 | Pogonion | 0.762 +/- 0.582 | 0.674-0.857 | 0.640 | 96.00 | 98.67 | 99.33 | 100.00 |
| 8 | Menton | 0.790 +/- 0.604 | 0.699-0.892 | 0.624 | 96.67 | 98.67 | 99.33 | 99.33 |
| 9 | Gnathion | 0.672 +/- 0.490 | 0.597-0.754 | 0.535 | 99.33 | 99.33 | 99.33 | 100.00 |
| 10 | Gonion | 1.568 +/- 1.020 | 1.410-1.733 | 1.410 | 68.67 | 84.00 | 92.67 | 96.00 |
| 11 | Lower incisal incision | 0.968 +/- 0.755 | 0.853-1.096 | 0.758 | 91.33 | 94.67 | 96.67 | 100.00 |
| 12 | Upper incisal incision | 0.753 +/- 0.693 | 0.652-0.874 | 0.578 | 96.67 | 98.67 | 98.67 | 99.33 |
| 13 | Upper lip | 1.221 +/- 0.567 | 1.131-1.312 | 1.176 | 88.67 | 98.00 | 100.00 | 100.00 |
| 14 | Lower lip | 0.875 +/- 0.418 | 0.808-0.941 | 0.788 | 98.00 | 100.00 | 100.00 | 100.00 |
| 15 | Subnasale | 0.963 +/- 0.854 | 0.831-1.103 | 0.739 | 89.33 | 91.33 | 96.00 | 98.67 |
| 16 | Soft tissue pogonion | 1.122 +/- 0.633 | 1.023-1.225 | 0.974 | 90.67 | 96.00 | 97.33 | 99.33 |
| 17 | Posterior nasal spine | 0.861 +/- 0.637 | 0.764-0.964 | 0.702 | 95.33 | 96.00 | 99.33 | 99.33 |
| 18 | Anterior nasal spine | 1.319 +/- 1.030 | 1.162-1.489 | 1.147 | 82.67 | 88.67 | 95.33 | 97.33 |
| 19 | Articulare | 1.582 +/- 1.147 | 1.406-1.772 | 1.237 | 73.33 | 79.33 | 88.67 | 95.33 |

### ISBI 2015 Test2 - per-landmark results (N = 100 images)

| # | Landmark | MRE +/- SD (mm) | MRE 95% CI | Median (mm) | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | Sella | 0.479 +/- 0.298 | 0.423-0.539 | 0.421 | 100.00 | 100.00 | 100.00 | 100.00 |
| 2 | Nasion | 0.907 +/- 0.731 | 0.771-1.058 | 0.724 | 92.00 | 96.00 | 98.00 | 99.00 |
| 3 | Orbitale | 2.264 +/- 0.923 | 2.087-2.451 | 2.201 | 40.00 | 66.00 | 79.00 | 98.00 |
| 4 | Porion | 1.952 +/- 2.824 | 1.498-2.589 | 1.216 | 70.00 | 77.00 | 85.00 | 92.00 |
| 5 | Subspinale (A point) | 1.255 +/- 0.711 | 1.120-1.396 | 1.097 | 84.00 | 94.00 | 98.00 | 100.00 |
| 6 | Supramentale (B point) | 2.519 +/- 1.166 | 2.292-2.751 | 2.550 | 33.00 | 49.00 | 68.00 | 89.00 |
| 7 | Pogonion | 0.670 +/- 0.424 | 0.588-0.753 | 0.566 | 98.00 | 100.00 | 100.00 | 100.00 |
| 8 | Menton | 0.661 +/- 0.429 | 0.579-0.747 | 0.595 | 98.00 | 100.00 | 100.00 | 100.00 |
| 9 | Gnathion | 0.531 +/- 0.332 | 0.469-0.598 | 0.478 | 100.00 | 100.00 | 100.00 | 100.00 |
| 10 | Gonion | 1.221 +/- 0.814 | 1.067-1.383 | 1.021 | 83.00 | 92.00 | 97.00 | 99.00 |
| 11 | Lower incisal incision | 0.960 +/- 0.738 | 0.828-1.115 | 0.828 | 94.00 | 99.00 | 99.00 | 99.00 |
| 12 | Upper incisal incision | 0.657 +/- 0.487 | 0.565-0.757 | 0.552 | 99.00 | 99.00 | 99.00 | 100.00 |
| 13 | Upper lip | 2.591 +/- 0.715 | 2.449-2.729 | 2.557 | 17.00 | 47.00 | 73.00 | 97.00 |
| 14 | Lower lip | 2.035 +/- 0.809 | 1.882-2.200 | 1.832 | 59.00 | 82.00 | 89.00 | 96.00 |
| 15 | Subnasale | 0.962 +/- 0.597 | 0.849-1.083 | 0.835 | 94.00 | 97.00 | 99.00 | 100.00 |
| 16 | Soft tissue pogonion | 4.625 +/- 1.315 | 4.368-4.884 | 4.514 | 3.00 | 5.00 | 9.00 | 31.00 |
| 17 | Posterior nasal spine | 1.030 +/- 0.636 | 0.909-1.162 | 0.988 | 89.00 | 98.00 | 100.00 | 100.00 |
| 18 | Anterior nasal spine | 1.304 +/- 0.778 | 1.157-1.461 | 1.195 | 81.00 | 92.00 | 97.00 | 99.00 |
| 19 | Articulare | 1.177 +/- 0.750 | 1.039-1.326 | 0.949 | 86.00 | 93.00 | 98.00 | 99.00 |

### CephAdoAdu (official validation split, all) - per-landmark results (N = 300 images)

| # | Landmark | MRE +/- SD (mm) | MRE 95% CI | Median (mm) | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | A | 1.047 +/- 0.713 | 0.968-1.127 | 0.914 | 90.33 | 96.33 | 97.33 | 100.00 |
| 2 | ANS | 0.890 +/- 0.664 | 0.817-0.969 | 0.772 | 95.67 | 98.33 | 99.00 | 99.33 |
| 3 | UI | 0.502 +/- 0.593 | 0.441-0.572 | 0.359 | 98.67 | 99.00 | 99.00 | 99.33 |
| 4 | UIA | 1.283 +/- 0.993 | 1.178-1.397 | 1.018 | 84.33 | 90.00 | 93.33 | 98.33 |
| 5 | Or | 1.168 +/- 1.048 | 1.058-1.300 | 0.950 | 87.67 | 93.33 | 96.33 | 98.67 |
| 6 | P | 1.534 +/- 1.147 | 1.409-1.666 | 1.230 | 77.33 | 84.67 | 91.00 | 95.67 |
| 7 | LI | 0.598 +/- 0.537 | 0.541-0.660 | 0.474 | 97.00 | 99.33 | 99.33 | 99.67 |
| 8 | LIA | 1.394 +/- 1.049 | 1.277-1.515 | 1.157 | 80.33 | 87.67 | 92.00 | 96.67 |
| 9 | Sn | 0.575 +/- 0.464 | 0.525-0.630 | 0.477 | 99.00 | 99.33 | 99.67 | 99.67 |
| 10 | Pog | 1.114 +/- 1.173 | 0.989-1.254 | 0.792 | 86.33 | 92.00 | 95.67 | 98.00 |

---

# Part 3 - Draft manuscript text: adolescent vs adult

All numbers come from `manuscript_metrics.md` / `summary.json` in this folder
(the 300 images of the official CephAdoAdu validation part - 150 adolescent, 150 adult,
10 landmarks - which were never used for training or model selection; 95 % CIs
from a 10,000-resample image-level percentile bootstrap).

Millimetre conversion: the dataset ships no physical pixel spacing and image
sizes range from about 600 to 3550 px on the longest side. We therefore follow
the official CephAdoAdu / CeLDA evaluation code (Wu et al., MICCAI 2024;
`code/test.py`, `infer_util.mappping_back`): coordinates are mapped to the image
rescaled so that its longest side is 2048 px and distances are multiplied by
0.1 mm. Numbers obtained with 0.1 mm per *original* pixel (what `train.py` /
`infer.py` log, e.g. the 1.045 mm in the README) are listed in the sensitivity
rows of Table 5 and should not be compared with published CephAdoAdu results.

## Methods sentence (evaluation protocol)

For CephAdoAdu, radial errors were converted to millimetres with the protocol
of the dataset's reference implementation: landmark coordinates were mapped to
the image rescaled to a longest side of 2048 pixels and a spacing of 0.1 mm per
pixel was applied.

## Results paragraph

On the 300 held-out CephAdoAdu images (the official validation part) the model reached an overall MRE of 1.010 mm
(95 % CI 0.971-1.050) with an SDR of 89.67 % (88.40-90.93) at 2 mm and 98.53 %
(98.07-98.97) at 4 mm. Accuracy was slightly higher in adolescents than in
adults (Table 5): the MRE was 0.972 +/- 0.983 mm (95 % CI 0.911-1.037) versus
1.049 +/- 0.892 mm (1.004-1.097), a difference of -0.077 mm whose 95 % CI
(-0.155 to +0.003) includes zero. The distribution of per-image mean radial
error was nevertheless shifted towards lower values in adolescents
(Mann-Whitney U = 8409, p < 0.001; rank-biserial r = -0.25), with a small
effect size (Cohen's d = -0.22; Welch t-test p = 0.058). The 2 mm SDR was
91.27 % (89.53-92.93) in adolescents and 88.07 % (86.20-89.87) in adults
(difference +3.20 percentage points, 95 % CI +0.67 to +5.80); from 2.5 mm
upwards the two groups were indistinguishable (differences of +1.33, -0.13 and
-0.27 points at 2.5, 3 and 4 mm, all CIs including zero). At the landmark
level, the difference was significant after Holm correction for three of the
ten landmarks, all in favour of adolescents: A point (0.870 vs 1.224 mm),
ANS (0.749 vs 1.030 mm) and porion (1.304 vs 1.764 mm). The remaining seven
landmarks showed no significant group difference.

## Discussion paragraph

Performance was largely consistent across age groups. The adolescent-adult gap
in MRE was below 0.1 mm with a confidence interval that includes zero, and the
success detection rates of the two groups coincided from the 2.5 mm threshold
upwards; the only aggregate difference was a 3-point advantage for adolescents
at the strictest 2 mm threshold. The age effect was therefore small and was
confined to three landmarks - A point, ANS and porion - while the dental
landmarks (UI, UIA, LI, LIA), orbitale, subnasale and pogonion were localised
equally well in both groups. Both groups are equally represented in the
official training split (200 images each), so this residual difference is
unlikely to be a sample-size artefact; whether it reflects image appearance or
annotation variability at those three landmarks in adults cannot be determined
from the present data, as no inter-observer reference is available for
CephAdoAdu. Two limitations apply: millimetre values rest on the dataset's
nominal conversion (longest side 2048 px at 0.1 mm/px) rather than on a
calibrated per-image spacing, and the evaluation uses the official validation
part of the public release rather than the test set reported by Wu et al.,
so absolute values are not directly comparable with their published test results.

---

# Part 4 - Manuscript corrections (items 3-6)

Every number below is taken from `manuscript_metrics.md`. Search the manuscript
for the "find" values and replace them; the paragraphs can be pasted as they are.

## 3. CephAdoAdu millimetre convention

Find and replace everywhere (abstract, results text, tables, figure captions, conclusion):

| Quantity (CephAdoAdu, all 300 images) | Old value (0.1 mm per original pixel) | Correct value (CeLDA convention) |
|---|---:|---:|
| MRE | 1.045 mm (also written 1.05) | **1.010 mm** (95 % CI 0.971-1.050) |
| SDR @ 2.0 mm | 87.53 % | **89.67 %** (88.40-90.93) |
| SDR @ 2.5 mm | 92.37 % | **94.00 %** (93.03-94.90) |
| SDR @ 3.0 mm | 95.27 % | **96.27 %** (95.50-97.00) |
| SDR @ 4.0 mm | 97.63 % | **98.53 %** (98.07-98.97) |
| MRE in pixels | 10.45 px | delete (a single pixel value is not meaningful: image sizes differ) |

Add to Methods (evaluation metrics):

> For CephAdoAdu, which provides no physical pixel spacing and whose images
> range from about 600 to 3550 pixels on the longest side, radial errors were
> converted to millimetres following the dataset's reference implementation
> (Wu et al., 2024): landmark coordinates were mapped to the image rescaled to a
> longest side of 2048 pixels and a spacing of 0.1 mm per pixel was applied.
> For Aariz the per-image pixel size supplied with the dataset was used, and
> for ISBI 2015 the official value of 0.1 mm per pixel.

If the manuscript mentions model selection: the CephAdoAdu checkpoint was
selected on a 10 % hold-out of the training part using the uncorrected
conversion. This affects only the units of the selection criterion, not the
predictions, so no retraining is needed; no sentence is required unless you
quote validation-curve values, in which case label them "0.1 mm per original
pixel (training-time monitor)".

## 4. Which CephAdoAdu images are evaluated

Replace "test set" / "300 test images" for CephAdoAdu with the wording below.

Dataset description (Methods):

> CephAdoAdu comprises 1000 lateral cephalograms (500 adolescents, 500 adults)
> annotated with 10 landmarks and divided by its authors into training (400),
> validation (300) and test (300) parts, each balanced by age group. The public
> release contains the training and validation parts. We trained on the
> training part, holding out 10 % of it for model selection, and report results
> on the 300 validation images (150 adolescents, 150 adults), which were never
> used for training or model selection.

Wherever your results are compared with CeLDA or other published CephAdoAdu numbers, add:

> Published results for CephAdoAdu refer to its test part, which is not part of
> the public release; our results are computed on the validation part with the
> same metric definition, so the comparison is indicative rather than
> like-for-like.

Table captions / column headers: "CephAdoAdu (validation part, n = 300)".

(Check the first paragraph against the dataset paper before submission: the
1000 / 400 / 300 / 300 figures are from Wu et al., and "the public release
contains the training and validation parts" is from your statement that the 300
images are the validation part.)

## 5. Aariz: test, not validation

| Quantity (Aariz, 26 landmarks) | Value in README/log (validation) | Correct test-set value |
|---|---:|---:|
| MRE | 1.073 mm (1.075 in the last epochs) | **1.105 +/- 1.313 mm** (95 % CI 1.013-1.202) |
| SDR @ 2.0 mm | 87.0 % | **86.85 %** (84.79-88.77) |
| SDR @ 2.5 mm | 92.1 % | **90.95 %** (89.26-92.51) |
| SDR @ 3.0 mm | 94.8 % | **93.90 %** (92.51-95.18) |
| SDR @ 4.0 mm | 97.2 % | **96.74 %** (95.74-97.64) |

Add to the Aariz dataset description if not already there:

> We used the 26 skeletal, dental and soft-tissue-profile landmarks retained by
> our loader (the first 26 of the 29 annotated landmarks; soft-tissue nasion,
> soft-tissue pogonion and subnasale were excluded), with the mean of the
> junior and senior annotations as ground truth.

Any comparison with methods evaluated on all 29 Aariz landmarks should say so.

## 6. Adolescent vs adult (Table 5 and its two paragraphs)

Replace Table 5 with:

| Metric | Adolescent (n = 150) | Adult (n = 150) | Difference, adolescent - adult (95 % CI) |
|---|---:|---:|---:|
| MRE +/- SD (mm) | 0.972 +/- 0.983 | 1.049 +/- 0.892 | -0.077 (-0.155 to +0.003) |
| MRE 95 % CI (mm) | 0.911-1.037 | 1.004-1.097 | |
| SDR @ 2.0 mm (%) | 91.27 (89.53-92.93) | 88.07 (86.20-89.87) | +3.20 (+0.67 to +5.80) |
| SDR @ 2.5 mm (%) | 94.67 (93.20-96.00) | 93.33 (92.00-94.53) | +1.33 (-0.53 to +3.20) |
| SDR @ 3.0 mm (%) | 96.20 (95.07-97.27) | 96.33 (95.40-97.27) | -0.13 (-1.60 to +1.33) |
| SDR @ 4.0 mm (%) | 98.40 (97.67-99.00) | 98.67 (98.07-99.20) | -0.27 (-1.13 to +0.60) |

Caption: "Accuracy by age group on the CephAdoAdu validation part. 95 %
confidence intervals from a 10,000-resample image-level percentile bootstrap.
Per-image mean radial error: Mann-Whitney U = 8409, p < 0.001 (rank-biserial
r = -0.25); Welch t-test p = 0.058; Cohen's d = -0.22."

Results and Discussion paragraphs: use the ones in
`cephadoadu_age_group_text.md` (already written for these numbers and for the
validation-part wording).

Statements that must not remain anywhere in the manuscript:

- that the model is "significantly" or "substantially" more accurate in
  adolescents overall (the MRE difference is 0.08 mm and its CI includes zero);
- an adolescent-adult MRE gap of about 0.25 mm, adolescent 0.923 mm, adult
  1.168 mm, or SDR@2 mm of 84.00 % for adults (all from the uncorrected conversion);
- five landmarks differing between groups (it is three: A point, ANS, porion).

What can be said: accuracy is comparable across age groups; adolescents have a
3-point advantage only at the strictest 2 mm threshold; the difference is
confined to A point, ANS and porion.

---

# Part 5 - How the numbers were verified

All of the following checks passed (`verify_eval.py`):

- Ground truth built by the evaluation script is identical to what the repository's own dataset loaders produce, for all three datasets.
- MRE and SDR equal the output of the repository's `delr/metrics.py` function on the same data.
- The README figures for ISBI 2015 Test1 (1.124 mm / 87.12 %) and Test2 (1.463 mm / 74.74 %) are reproduced exactly; so is the CephAdoAdu figure under the old conversion (1.045 mm / 87.53 %).
- Prediction IDs match the evaluation sets exactly (150, 150, 100, 300 images); no missing or extra images.
- Aariz: landmark order is identical in every junior and senior annotation file; 29 landmarks per file, first 26 used.
- CephAdoAdu: every annotation holds landmark types 1-10 exactly once; 150 adolescent and 150 adult images; no image appears in both age folders.
- No ground-truth landmark lies outside the range where the loader's coordinate clipping would alter it.
- The vectorised bootstrap equals a naive resample-and-recompute; the percentile interval agrees with BCa and t-intervals to within 0.003 mm.
- Holm correction matches statsmodels; the Mann-Whitney effect-size sign was checked against P(adolescent > adult).
- Results are reproducible: each analysis has its own fixed seed, and re-running with a subset of datasets gives identical numbers.

Source of the CephAdoAdu conversion and landmark names: `code/test.py` and
`code/infer_util.py` of github.com/ShanghaiTech-IMPACT/CeLDA. Their
`mappping_back` swaps x and y when rescaling; the isotropic version intended by
that code is used here (their literal code would give 1.058 mm overall).

# Part 6 - Open points

- Nothing has been pushed to GitHub: the token supplied has no write access to the repository.
- The per-landmark CSV files, raw error arrays, failure lists and `summary.json` were regenerated on 2026-10-06 with identical numbers and are saved in `results/manuscript_metrics/` next to this file.
- The evaluation script was written for this analysis; it is not the one from the original zip.
- Inference was not re-run: metrics are computed from the prediction files already in the repository.
- Dataset-paper figures quoted for CephAdoAdu (1000 images, 400/300/300 split, CeLDA 1.05 mm) should be checked against the PDF before citing.
- ISBI 2015 Test2 soft-tissue pogonion (4.6 mm, 3 % SDR at 2 mm) reflects the known annotation inconsistency between Test1 and Test2.
- Confidence intervals reflect test-set sampling only; each model is a single training run.

---

# Part 7 - Per-device accuracy, failure cases and rank correlations (re-run 2026-10-06)

Recomputed from the saved prediction files. A failure is a radial error above 4 mm.

## Aariz - accuracy by imaging device (test set)

| Device | N images | Pixel size (mm) | MRE +/- SD (mm) | MRE 95% CI | SDR@2.0 (%) | SDR@2.5 (%) | SDR@3.0 (%) | SDR@4.0 (%) |
|---|---|---|---|---|---|---|---|---|
| ART Plus | 55 | 0.1 | 1.411 +/- 1.579 | 1.290-1.548 | 80.77 | 86.50 | 90.42 | 94.83 |
| Veraviewepocs 2D | 26 | 0.144 | 0.687 +/- 0.560 | 0.647-0.729 | 96.75 | 98.22 | 99.41 | 99.85 |
| Hyperion X5 | 21 | 0.089 | 0.422 +/- 0.374 | 0.370-0.489 | 99.63 | 99.82 | 99.82 | 100.00 |
| ProMax with ProTouch | 20 | 0.139 | 1.253 +/- 1.371 | 1.125-1.411 | 86.15 | 92.50 | 95.19 | 97.69 |
| Rotograph EVO | 13 | 0.135 | 1.993 +/- 1.629 | 1.789-2.241 | 64.79 | 71.30 | 79.59 | 88.17 |
| Smart3D | 9 | 0.1 | 0.428 +/- 0.315 | 0.392-0.473 | 100.00 | 100.00 | 100.00 | 100.00 |
| ProMax 2D | 6 | 0.139 | 1.102 +/- 0.748 | 0.958-1.265 | 85.26 | 92.95 | 98.72 | 100.00 |
| **All** | 150 |  | 1.105 +/- 1.313 |  | 86.85 | 90.95 | 93.90 | 96.74 |

Check: 7 devices, 150 images; image-weighted mean of the device MREs = 1.105 mm (overall 1.105 mm). Kruskal-Wallis on per-image mean error across devices: H = 118.28, p = 3.741e-23.

Aariz inter-observer (junior vs senior) distance on the same landmarks: 0.520 +/- 1.113 mm (model vs their mean: 1.105 mm).

## Failure cases (named by landmark)

### Aariz (test, 26 landmarks)

127 of 3900 landmark predictions (3.26 %) exceed 4 mm; 58 of 150 images contain at least one.

Failures (> 4 mm) by landmark, most frequent first:

| # | Landmark | n > 4 mm | % of images | MRE (mm) | Max error (mm) |
|---|---|---|---|---|---|
| 10 | Ramus | 21 | 14.0 | 2.094 | 10.47 |
| 13 | Condylion | 16 | 10.7 | 2.000 | 16.52 |
| 16 | Porion | 12 | 8.0 | 1.552 | 7.89 |
| 12 | Articulare | 11 | 7.3 | 1.577 | 20.29 |
| 15 | Gonion | 11 | 7.3 | 1.473 | 7.15 |
| 20 | Upper 2nd PM Cusp Tip | 9 | 6.0 | 1.336 | 7.14 |
| 2 | Anterior Nasal Spine | 7 | 4.7 | 1.214 | 5.38 |
| 8 | Posterior Nasal Spine | 7 | 4.7 | 1.412 | 11.58 |
| 23 | Upper Molar Cusp Tip | 7 | 4.7 | 1.321 | 11.11 |
| 17 | Lower 2nd PM Cusp Tip | 6 | 4.0 | 1.277 | 12.30 |
| 19 | Lower Molar Cusp Tip | 5 | 3.3 | 1.058 | 10.08 |
| 25 | Labrale inferius | 4 | 2.7 | 1.097 | 16.61 |
| 6 | Orbitale | 3 | 2.0 | 1.292 | 14.48 |
| 5 | Nasion | 2 | 1.3 | 0.859 | 6.81 |
| 21 | Upper Incisor Apex | 2 | 1.3 | 1.154 | 4.45 |
| 24 | Lower Incisor Apex | 2 | 1.3 | 1.390 | 4.89 |
| 9 | Pronasale | 1 | 0.7 | 0.791 | 8.85 |
| 26 | Labrale superius | 1 | 0.7 | 0.742 | 16.63 |
| 1 | A-point | 0 | 0.0 | 0.874 | 3.24 |
| 3 | B-point | 0 | 0.0 | 0.834 | 3.50 |
| 4 | Menton | 0 | 0.0 | 0.486 | 2.38 |
| 7 | Pogonion | 0 | 0.0 | 0.553 | 3.27 |
| 11 | Sella | 0 | 0.0 | 0.631 | 3.00 |
| 14 | Gnathion | 0 | 0.0 | 0.414 | 2.26 |
| 18 | Lower Incisor Tip | 0 | 0.0 | 0.726 | 2.51 |
| 22 | Upper Incisor Tip | 0 | 0.0 | 0.577 | 3.77 |

The 15 largest individual errors:

| Rank | Image | # | Landmark | Error (mm) | Group / device |
|---|---|---|---|---|---|
| 1 | cks2ip8g62b7b0yuffrlb7xa1 | 12 | Articulare | 20.29 | ART Plus |
| 2 | cl5lg05un01hm074k3dwy9l5q | 26 | Labrale superius | 16.63 | ProMax with ProTouch |
| 3 | cl5lg05un01hm074k3dwy9l5q | 25 | Labrale inferius | 16.61 | ProMax with ProTouch |
| 4 | cks2ip8g62b7b0yuffrlb7xa1 | 13 | Condylion | 16.52 | ART Plus |
| 5 | cks2ip8g62b7b0yuffrlb7xa1 | 6 | Orbitale | 14.48 | ART Plus |
| 6 | cks2ip8g02asq0yuf59owfht0 | 17 | Lower 2nd PM Cusp Tip | 12.30 | ART Plus |
| 7 | cl777aklx03ua076whaie06kb | 8 | Posterior Nasal Spine | 11.58 | Rotograph EVO |
| 8 | cks2ip8fq29zp0yuf7cxd3bz2 | 17 | Lower 2nd PM Cusp Tip | 11.53 | ART Plus |
| 9 | cks2ip8g02asq0yuf59owfht0 | 23 | Upper Molar Cusp Tip | 11.11 | ART Plus |
| 10 | cks2ip8g62b7b0yuffrlb7xa1 | 10 | Ramus | 10.47 | ART Plus |
| 11 | cks2ip8g02asq0yuf59owfht0 | 19 | Lower Molar Cusp Tip | 10.08 | ART Plus |
| 12 | cl777aklx03ua076whaie06kb | 10 | Ramus | 9.71 | Rotograph EVO |
| 13 | cks2ip8fz2aq80yuf2pz61jh3 | 12 | Articulare | 9.08 | ART Plus |
| 14 | cl5lg05ul01gq074kb4xm8mml | 9 | Pronasale | 8.85 | ProMax with ProTouch |
| 15 | cl7ww1jcp9cfk084fgkua8l9o | 10 | Ramus | 8.79 | Rotograph EVO |

The 5 images with the highest mean error:

| Image | Image MRE (mm) | Landmarks > 4 mm | Worst landmark | Group / device |
|---|---|---|---|---|
| cks2ip8g62b7b0yuffrlb7xa1 | 3.42 | 4 | Articulare (20.29 mm) | ART Plus |
| cl777aklx03ua076whaie06kb | 2.99 | 7 | Posterior Nasal Spine (11.58 mm) | Rotograph EVO |
| cl76jfqyd0e3l07613b4o2677 | 2.87 | 10 | Nasion (6.33 mm) | Rotograph EVO |
| cks2ip8g02asq0yuf59owfht0 | 2.72 | 4 | Lower 2nd PM Cusp Tip (12.30 mm) | ART Plus |
| cks2ip8fq29zz0yuf15jsfhlu | 2.65 | 6 | Ramus (8.29 mm) | ART Plus |

### ISBI 2015 Test1 (19 landmarks)

46 of 2850 landmark predictions (1.61 %) exceed 4 mm; 38 of 150 images contain at least one.

Failures (> 4 mm) by landmark, most frequent first:

| # | Landmark | n > 4 mm | % of images | MRE (mm) | Max error (mm) |
|---|---|---|---|---|---|
| 4 | Porion | 9 | 6.0 | 1.820 | 5.19 |
| 2 | Nasion | 7 | 4.7 | 1.232 | 5.54 |
| 19 | Articulare | 7 | 4.7 | 1.582 | 6.50 |
| 10 | Gonion | 6 | 4.0 | 1.568 | 4.63 |
| 18 | Anterior nasal spine | 4 | 2.7 | 1.319 | 6.94 |
| 5 | Subspinale (A point) | 3 | 2.0 | 1.661 | 6.11 |
| 1 | Sella | 2 | 1.3 | 0.779 | 31.90 |
| 3 | Orbitale | 2 | 1.3 | 1.284 | 4.85 |
| 15 | Subnasale | 2 | 1.3 | 0.963 | 4.35 |
| 8 | Menton | 1 | 0.7 | 0.790 | 4.89 |
| 12 | Upper incisal incision | 1 | 0.7 | 0.753 | 6.36 |
| 16 | Soft tissue pogonion | 1 | 0.7 | 1.122 | 4.10 |
| 17 | Posterior nasal spine | 1 | 0.7 | 0.861 | 4.47 |
| 6 | Supramentale (B point) | 0 | 0.0 | 1.121 | 3.45 |
| 7 | Pogonion | 0 | 0.0 | 0.762 | 3.44 |
| 9 | Gnathion | 0 | 0.0 | 0.672 | 3.16 |
| 11 | Lower incisal incision | 0 | 0.0 | 0.968 | 3.57 |
| 13 | Upper lip | 0 | 0.0 | 1.221 | 2.88 |
| 14 | Lower lip | 0 | 0.0 | 0.875 | 2.39 |

The 15 largest individual errors:

| Rank | Image | # | Landmark | Error (mm) |
|---|---|---|---|---|
| 1 | 181 | 1 | Sella | 31.90 |
| 2 | 194 | 1 | Sella | 14.36 |
| 3 | 169 | 18 | Anterior nasal spine | 6.94 |
| 4 | 267 | 19 | Articulare | 6.50 |
| 5 | 208 | 12 | Upper incisal incision | 6.36 |
| 6 | 295 | 5 | Subspinale (A point) | 6.11 |
| 7 | 162 | 2 | Nasion | 5.54 |
| 8 | 269 | 18 | Anterior nasal spine | 5.39 |
| 9 | 243 | 19 | Articulare | 5.30 |
| 10 | 215 | 4 | Porion | 5.19 |
| 11 | 293 | 4 | Porion | 5.16 |
| 12 | 289 | 4 | Porion | 4.90 |
| 13 | 208 | 8 | Menton | 4.89 |
| 14 | 160 | 3 | Orbitale | 4.85 |
| 15 | 281 | 4 | Porion | 4.78 |

The 5 images with the highest mean error:

| Image | Image MRE (mm) | Landmarks > 4 mm | Worst landmark |
|---|---|---|---|
| 181 | 2.59 | 1 | Sella (31.90 mm) |
| 208 | 2.47 | 4 | Upper incisal incision (6.36 mm) |
| 194 | 2.34 | 1 | Sella (14.36 mm) |
| 267 | 1.68 | 2 | Articulare (6.50 mm) |
| 256 | 1.64 | 1 | Nasion (4.33 mm) |

Inter-observer (junior vs senior) distance: 2.363 +/- 2.164 mm.

### ISBI 2015 Test2 (19 landmarks)

102 of 1900 landmark predictions (5.37 %) exceed 4 mm; 77 of 100 images contain at least one.

Failures (> 4 mm) by landmark, most frequent first:

| # | Landmark | n > 4 mm | % of images | MRE (mm) | Max error (mm) |
|---|---|---|---|---|---|
| 16 | Soft tissue pogonion | 69 | 69.0 | 4.625 | 8.13 |
| 6 | Supramentale (B point) | 11 | 11.0 | 2.519 | 5.92 |
| 4 | Porion | 8 | 8.0 | 1.952 | 24.19 |
| 14 | Lower lip | 4 | 4.0 | 2.035 | 5.05 |
| 13 | Upper lip | 3 | 3.0 | 2.591 | 4.07 |
| 3 | Orbitale | 2 | 2.0 | 2.264 | 5.76 |
| 2 | Nasion | 1 | 1.0 | 0.907 | 4.81 |
| 10 | Gonion | 1 | 1.0 | 1.221 | 4.93 |
| 11 | Lower incisal incision | 1 | 1.0 | 0.960 | 6.03 |
| 18 | Anterior nasal spine | 1 | 1.0 | 1.304 | 4.18 |
| 19 | Articulare | 1 | 1.0 | 1.177 | 4.12 |
| 1 | Sella | 0 | 0.0 | 0.479 | 1.68 |
| 5 | Subspinale (A point) | 0 | 0.0 | 1.255 | 3.73 |
| 7 | Pogonion | 0 | 0.0 | 0.670 | 2.21 |
| 8 | Menton | 0 | 0.0 | 0.661 | 2.07 |
| 9 | Gnathion | 0 | 0.0 | 0.531 | 1.49 |
| 12 | Upper incisal incision | 0 | 0.0 | 0.657 | 3.02 |
| 15 | Subnasale | 0 | 0.0 | 0.962 | 3.10 |
| 17 | Posterior nasal spine | 0 | 0.0 | 1.030 | 2.86 |

The 15 largest individual errors:

| Rank | Image | # | Landmark | Error (mm) |
|---|---|---|---|---|
| 1 | 302 | 4 | Porion | 24.19 |
| 2 | 393 | 4 | Porion | 12.10 |
| 3 | 347 | 4 | Porion | 8.61 |
| 4 | 361 | 16 | Soft tissue pogonion | 8.13 |
| 5 | 389 | 16 | Soft tissue pogonion | 7.40 |
| 6 | 303 | 16 | Soft tissue pogonion | 7.22 |
| 7 | 346 | 16 | Soft tissue pogonion | 7.03 |
| 8 | 331 | 16 | Soft tissue pogonion | 6.93 |
| 9 | 347 | 16 | Soft tissue pogonion | 6.92 |
| 10 | 397 | 16 | Soft tissue pogonion | 6.80 |
| 11 | 355 | 16 | Soft tissue pogonion | 6.75 |
| 12 | 376 | 16 | Soft tissue pogonion | 6.67 |
| 13 | 371 | 16 | Soft tissue pogonion | 6.64 |
| 14 | 370 | 16 | Soft tissue pogonion | 6.42 |
| 15 | 360 | 16 | Soft tissue pogonion | 6.35 |

The 5 images with the highest mean error:

| Image | Image MRE (mm) | Landmarks > 4 mm | Worst landmark |
|---|---|---|---|
| 302 | 2.49 | 1 | Porion (24.19 mm) |
| 393 | 1.99 | 3 | Porion (12.10 mm) |
| 331 | 1.98 | 2 | Soft tissue pogonion (6.93 mm) |
| 376 | 1.87 | 1 | Soft tissue pogonion (6.67 mm) |
| 349 | 1.82 | 2 | Lower incisal incision (6.03 mm) |

Inter-observer (junior vs senior) distance: 1.514 +/- 1.405 mm.

### CephAdoAdu (official validation part, 10 landmarks)

44 of 3000 landmark predictions (1.47 %) exceed 4 mm; 40 of 300 images contain at least one.

Failures (> 4 mm) by landmark, most frequent first:

| # | Landmark | n > 4 mm | % of images | MRE (mm) | Max error (mm) |
|---|---|---|---|---|---|
| 6 | P | 13 | 4.3 | 1.534 | 7.72 |
| 8 | LIA | 10 | 3.3 | 1.394 | 7.22 |
| 10 | Pog | 6 | 2.0 | 1.114 | 9.87 |
| 4 | UIA | 5 | 1.7 | 1.283 | 7.06 |
| 5 | Or | 4 | 1.3 | 1.168 | 12.07 |
| 2 | ANS | 2 | 0.7 | 0.890 | 6.59 |
| 3 | UI | 2 | 0.7 | 0.502 | 6.52 |
| 7 | LI | 1 | 0.3 | 0.598 | 5.14 |
| 9 | Sn | 1 | 0.3 | 0.575 | 5.04 |
| 1 | A | 0 | 0.0 | 1.047 | 3.93 |

The 15 largest individual errors:

| Rank | Image | # | Landmark | Error (mm) | Group / device |
|---|---|---|---|---|---|
| 1 | 4cfb147bcb3c4f44bf50133869e08a67 | 5 | Or | 12.07 | adolescent |
| 2 | 3fddd4ae901f451198ae41553394cf62 | 10 | Pog | 9.87 | adolescent |
| 3 | 6e3c7652b2f34db6a5072d5d7ec116ef | 10 | Pog | 8.08 | adolescent |
| 4 | 09a848d9656348afbb908d433c382009 | 6 | P | 7.72 | adolescent |
| 5 | 4ab47eff1f794f45b011bc6f3812b782 | 8 | LIA | 7.22 | adolescent |
| 6 | 00e416838e72477d9287288698fad079 | 4 | UIA | 7.06 | adolescent |
| 7 | TC807 | 10 | Pog | 6.82 | adult |
| 8 | 0e4665273c4748c28b6f31626db294d8 | 10 | Pog | 6.73 | adolescent |
| 9 | d2293f54d58d4f1689d6739deaed1ef9 | 2 | ANS | 6.59 | adult |
| 10 | 3f42983e87dc42d6965586f6f735a8ed | 10 | Pog | 6.54 | adolescent |
| 11 | 645563ad05de4f3e8bd25983e7c0e8ba | 3 | UI | 6.52 | adolescent |
| 12 | TC1152 | 6 | P | 6.51 | adult |
| 13 | 1f2bd805f205454ab184a7f07618e57a | 8 | LIA | 6.44 | adolescent |
| 14 | 3c89b11adc0e479395278564e0cbef9a | 5 | Or | 6.19 | adolescent |
| 15 | 5e8b639e27364576ae7c094147e1fb7d | 4 | UIA | 6.11 | adolescent |

The 5 images with the highest mean error:

| Image | Image MRE (mm) | Landmarks > 4 mm | Worst landmark | Group / device |
|---|---|---|---|---|
| 6e3c7652b2f34db6a5072d5d7ec116ef | 2.51 | 1 | Pog (8.08 mm) | adolescent |
| 00e416838e72477d9287288698fad079 | 2.47 | 3 | UIA (7.06 mm) | adolescent |
| TC727 | 2.46 | 2 | UIA (5.36 mm) | adult |
| 4cfb147bcb3c4f44bf50133869e08a67 | 2.21 | 1 | Or (12.07 mm) | adolescent |
| 4ab47eff1f794f45b011bc6f3812b782 | 2.16 | 1 | LIA (7.22 mm) | adolescent |

Failures by age group: adolescent 24 of 1500, adult 20 of 1500.

## Rank correlations

| Quantity | n | Spearman rho | p | Pearson r | p |
|---|---|---|---|---|---|
| Aariz: per-landmark model MRE vs junior-senior distance (26 landmarks) | 26 | +0.306 | 0.1279 | +0.387 | 0.05096 |
| Aariz: per-image model MRE vs junior-senior distance (150 images) | 150 | +0.647 | 3.509e-19 | +0.585 | 3.858e-15 |
| Aariz: all landmark instances, model error vs junior-senior distance | 3900 | +0.116 | 3.251e-13 | +0.215 | 4.481e-42 |
| Aariz: per-image model MRE vs pixel size | 150 | +0.122 | 0.1368 | +0.103 | 0.2095 |
| ISBI 2015 Test1: per-landmark model MRE vs junior-senior distance (19 landmarks) | 19 | +0.705 | 0.000744 | +0.473 | 0.04066 |
| ISBI 2015 Test1: per-image model MRE vs junior-senior distance | 150 | +0.348 | 1.309e-05 | +0.445 | 1.125e-08 |
| ISBI 2015 Test2: per-landmark model MRE vs junior-senior distance (19 landmarks) | 19 | +0.837 | 7.946e-06 | +0.769 | 0.0001189 |
| ISBI 2015 Test2: per-image model MRE vs junior-senior distance | 100 | +0.319 | 0.001197 | +0.252 | 0.01143 |
| CephAdoAdu: per-image model MRE vs CeLDA mm-per-pixel factor | 300 | -0.033 | 0.5721 | +0.072 | 0.2126 |

### Aariz - model error and inter-observer distance by landmark

| # | Landmark | Model MRE (mm) | Junior-senior distance (mm) |
|---|---|---|---|
| 1 | A-point | 0.874 | 0.496 |
| 2 | Anterior Nasal Spine | 1.214 | 0.609 |
| 3 | B-point | 0.834 | 0.706 |
| 4 | Menton | 0.486 | 0.823 |
| 5 | Nasion | 0.859 | 0.568 |
| 6 | Orbitale | 1.292 | 1.023 |
| 7 | Pogonion | 0.553 | 0.271 |
| 8 | Posterior Nasal Spine | 1.412 | 0.227 |
| 9 | Pronasale | 0.791 | 0.230 |
| 10 | Ramus | 2.094 | 0.877 |
| 11 | Sella | 0.631 | 0.034 |
| 12 | Articulare | 1.577 | 0.695 |
| 13 | Condylion | 2.000 | 0.807 |
| 14 | Gnathion | 0.414 | 0.452 |
| 15 | Gonion | 1.473 | 1.310 |
| 16 | Porion | 1.552 | 1.408 |
| 17 | Lower 2nd PM Cusp Tip | 1.277 | 0.000 |
| 18 | Lower Incisor Tip | 0.726 | 0.349 |
| 19 | Lower Molar Cusp Tip | 1.058 | 0.040 |
| 20 | Upper 2nd PM Cusp Tip | 1.336 | 0.000 |
| 21 | Upper Incisor Apex | 1.154 | 1.083 |
| 22 | Upper Incisor Tip | 0.577 | 0.349 |
| 23 | Upper Molar Cusp Tip | 1.321 | 0.010 |
| 24 | Lower Incisor Apex | 1.390 | 0.810 |
| 25 | Labrale inferius | 1.097 | 0.228 |
| 26 | Labrale superius | 0.742 | 0.124 |

---

# Part 8 - Predicted uncertainty and failure cases (Aariz test set, re-run 2026-10-06)

Inference re-run with `checkpoints/Aariz_26/best_model.pt`. Largest difference between re-run and saved predictions: 0.035 original pixels; MRE re-run 1.1051 mm, saved predictions 1.1051 mm. All statistics below use the errors of the saved prediction files.

Uncertainty = exp(predicted log-scale) of the last refinement update, converted from network pixels to millimetres with the image's pixel size and resize factors.

## Correlation over all landmark predictions

| Uncertainty unit | n | Spearman rho | Pearson r |
|---|---:|---:|---:|
| millimetres | 3900 | 0.605 | 0.429 |
| network pixels (raw output) | 3900 | 0.261 | 0.306 |

Uncertainty (mm): mean 0.208, median 0.180. Error (mm): mean 1.105, median 0.732. Ratio mean error / mean uncertainty = 5.31; median of per-prediction ratio = 4.11; least-squares slope through origin = 4.49.

## Deciles of predicted uncertainty (mm)

| Decile | n | Uncertainty range (mm) | Mean uncertainty (mm) | MRE (mm) | SDR 2 mm (%) | Error / uncertainty |
|---:|---:|---|---:|---:|---:|---:|
| 1 | 390 | 0.038-0.085 | 0.069 | 0.330 | 100.0 | 4.77 |
| 2 | 390 | 0.085-0.118 | 0.102 | 0.462 | 99.7 | 4.52 |
| 3 | 390 | 0.118-0.141 | 0.130 | 0.526 | 99.2 | 4.04 |
| 4 | 390 | 0.141-0.160 | 0.150 | 0.711 | 96.9 | 4.73 |
| 5 | 390 | 0.160-0.180 | 0.170 | 0.904 | 93.8 | 5.32 |
| 6 | 390 | 0.180-0.202 | 0.191 | 1.148 | 88.2 | 6.02 |
| 7 | 390 | 0.202-0.229 | 0.215 | 1.370 | 79.2 | 6.37 |
| 8 | 390 | 0.229-0.266 | 0.247 | 1.469 | 81.5 | 5.96 |
| 9 | 390 | 0.266-0.330 | 0.294 | 1.614 | 74.6 | 5.49 |
| 10 | 390 | 0.330-4.809 | 0.515 | 2.517 | 55.1 | 4.89 |

## The 20 largest errors with their predicted uncertainty

| Rank | Image | Device | Landmark | Error (mm) | Predicted uncertainty (mm) | Uncertainty percentile |
|---:|---|---|---|---:|---:|---:|
| 1 | cks2ip8g62b7b0yuffrlb7xa1 | ART Plus | Articulare | 20.29 | 0.759 | 99 |
| 2 | cl5lg05un01hm074k3dwy9l5q | ProMax with ProTouch | Labrale superius | 16.63 | 0.293 | 85 |
| 3 | cl5lg05un01hm074k3dwy9l5q | ProMax with ProTouch | Labrale inferius | 16.61 | 0.263 | 79 |
| 4 | cks2ip8g62b7b0yuffrlb7xa1 | ART Plus | Condylion | 16.52 | 0.600 | 98 |
| 5 | cks2ip8g62b7b0yuffrlb7xa1 | ART Plus | Orbitale | 14.48 | 1.097 | 100 |
| 6 | cks2ip8g02asq0yuf59owfht0 | ART Plus | Lower 2nd PM Cusp Tip | 12.30 | 0.238 | 73 |
| 7 | cl777aklx03ua076whaie06kb | Rotograph EVO | Posterior Nasal Spine | 11.58 | 0.719 | 99 |
| 8 | cks2ip8fq29zp0yuf7cxd3bz2 | ART Plus | Lower 2nd PM Cusp Tip | 11.53 | 0.407 | 95 |
| 9 | cks2ip8g02asq0yuf59owfht0 | ART Plus | Upper Molar Cusp Tip | 11.11 | 0.291 | 85 |
| 10 | cks2ip8g62b7b0yuffrlb7xa1 | ART Plus | Ramus | 10.47 | 1.939 | 100 |
| 11 | cks2ip8g02asq0yuf59owfht0 | ART Plus | Lower Molar Cusp Tip | 10.08 | 0.283 | 83 |
| 12 | cl777aklx03ua076whaie06kb | Rotograph EVO | Ramus | 9.71 | 0.611 | 98 |
| 13 | cks2ip8fz2aq80yuf2pz61jh3 | ART Plus | Articulare | 9.08 | 0.323 | 89 |
| 14 | cl5lg05ul01gq074kb4xm8mml | ProMax with ProTouch | Pronasale | 8.85 | 2.551 | 100 |
| 15 | cl7ww1jcp9cfk084fgkua8l9o | Rotograph EVO | Ramus | 8.79 | 0.328 | 90 |
| 16 | cks2ip8g42b0s0yuf23y8917i | ART Plus | Articulare | 8.42 | 0.257 | 78 |
| 17 | cks2ip8fq29zz0yuf15jsfhlu | ART Plus | Ramus | 8.29 | 0.510 | 97 |
| 18 | cks2ip8g32av80yuf73500e1b | ART Plus | Labrale inferius | 8.06 | 4.809 | 100 |
| 19 | cks2ip8fq29zp0yuf7cxd3bz2 | ART Plus | Upper Molar Cusp Tip | 8.00 | 0.387 | 94 |
| 20 | cl5lg05ul01gm074k2rztekih | ProMax with ProTouch | Upper Molar Cusp Tip | 7.90 | 0.767 | 99 |

Of the 127 errors above 4 mm, 69 are in the top uncertainty decile and 123 are above the median uncertainty; median uncertainty of these failures 0.358 mm versus 0.177 mm for the other predictions.

## Overlays

- `overlay_aariz_1_cks2ip8g62b7b0yuffrlb7xa1.jpg` (ART Plus): 12 Articulare 20.3 mm (u 0.76), 13 Condylion 16.5 mm (u 0.60), 6 Orbitale 14.5 mm (u 1.10), 10 Ramus 10.5 mm (u 1.94)
- `overlay_aariz_2_cl5lg05un01hm074k3dwy9l5q.jpg` (ProMax with ProTouch): 26 Labrale superius 16.6 mm (u 0.29), 25 Labrale inferius 16.6 mm (u 0.26)
- `overlay_aariz_3_cks2ip8g02asq0yuf59owfht0.jpg` (ART Plus): 17 Lower 2nd PM Cusp Tip 12.3 mm (u 0.24), 23 Upper Molar Cusp Tip 11.1 mm (u 0.29), 19 Lower Molar Cusp Tip 10.1 mm (u 0.28), 20 Upper 2nd PM Cusp Tip 7.1 mm (u 0.27)
- `overlay_aariz_4_cl777aklx03ua076whaie06kb.jpg` (Rotograph EVO): 8 Posterior Nasal Spine 11.6 mm (u 0.72), 10 Ramus 9.7 mm (u 0.61), 12 Articulare 6.2 mm (u 0.52), 13 Condylion 5.7 mm (u 0.58), 16 Porion 4.9 mm (u 0.47), 21 Upper Incisor Apex 4.4 mm (u 0.39), 15 Gonion 4.4 mm (u 0.81)
- `overlay_aariz_5_cks2ip8fq29zp0yuf7cxd3bz2.jpg` (ART Plus): 17 Lower 2nd PM Cusp Tip 11.5 mm (u 0.41), 23 Upper Molar Cusp Tip 8.0 mm (u 0.39), 20 Upper 2nd PM Cusp Tip 7.1 mm (u 0.43), 19 Lower Molar Cusp Tip 6.1 mm (u 0.33), 10 Ramus 5.7 mm (u 0.35), 12 Articulare 5.1 mm (u 0.40)
- `overlay_aariz_6_cks2ip8fz2aq80yuf2pz61jh3.jpg` (ART Plus): 12 Articulare 9.1 mm (u 0.32), 19 Lower Molar Cusp Tip 5.3 mm (u 0.20)

Green circle: reference; filled dot: prediction (red and numbered if error > 4 mm); yellow line joins the two.

---

# Part 9 - Changes made to the manuscript on 2026-10-06

File edited: `updated_manuscript/Manuscript_anonymised_IntOrthod.docx` (also replaced inside
`IntOrthod_submission_package.zip`). The versions from before these edits are in
`updated_manuscript/previous_version/`. The supplement, highlights and title page were not changed.

Everything was recomputed from the prediction files; the uncertainty analysis re-ran inference with
the released Aariz checkpoint, which reproduces the saved predictions to within 0.04 pixels.

## Confirmed without change

- Tables 2, 3, 4, 5, 6 and supplementary tables S1-S6: every value matches the re-run.
- Per-device table: seven devices, 150 images, weighted mean 1.105 mm.
- Landmark names in all tables and in the text (Aariz names are read from the annotation files).
- Ablation numbers (recomputed from the ablation prediction files) and the 1.188 / 1.132 / 1.124 mm
  validation values of the three ISBI training phases.
- Parameter counts: 53.9 million in total, 27.9 million in the backbone.
- Abstract, highlights and conclusions: no statement depends on the corrected items.

## Corrected

| Where | Was | Now | Why |
|---|---|---|---|
| 3.2, posterior landmarks within 2 mm | 63-76% | 63-79% | articulare is 79.33% |
| 3.2, junior-senior disagreement | about 1.3 mm at porion, gonion and condylion; 0.06 mm at sella | porion 1.41 mm, gonion 1.31 mm, condylion 0.81 mm, sella 0.03 mm | condylion is not among the highest; values recomputed on the test images |
| 3.5, correlation | rho = 0.606; r = 0.430 | rho = 0.61; r = 0.43 | re-run gives 0.605 and 0.429; two decimals are what the data support |
| 3.5, least confident decile | SDR 54.6% | 55.1% | re-run |
| 3.5, calibration | "roughly constant factor of about 4.8" | "factor of about 4 to 6 in every decile (about 5 overall)" | ratio varies from 4.0 to 6.4 across deciles |
| 3.5, added | - | 123 of 127 errors above 4 mm have above-median uncertainty, 69 are in the least confident decile; median uncertainty 0.36 vs 0.18 mm | replaces the unsupported "median of about 0.15 mm" |
| 3.5, failure cases | two patterns: contralateral ramus (low to moderate uncertainty); earrings over the temporomandibular region in most other cases | four patterns, described below | the previous description did not match the images |
| 4, landmark paragraph | posterior landmarks have "the greatest junior-senior disagreement" | porion and gonion showed the largest | condylion, articulare and ramus rank 8th, 10th and 5th of 26 |
| 4, uncertainty paragraph | "the uncertainty did not detect the case in which the network confused the two mandibular rami" | absolute values are several times too small, and wrong-tooth errors carry only moderately raised uncertainty | in that image the uncertainty was in the top 2% |
| 2.7 | "predicted uncertainty" | adds the definition (predicted scale of the final refinement update, converted to millimetres) | so the correlation is reproducible |

## Failure cases as now described (overlays in `results/manuscript_metrics/`)

1. `cks2ip8g62b7b0yuffrlb7xa1` (ART Plus): ear rods not superimposed; ramus 10.5, condylion 16.5, articulare 20.3 mm
   anterior to the reference, orbitale 14.5 mm. Uncertainty 0.6-1.9 mm, top 2% of the test set.
2. `cl5lg05un01hm074k3dwy9l5q` (ProMax with ProTouch): labrale superius and inferius each 16.6 mm off. The reference
   labels are interchanged in both annotators' files; with the labels exchanged the errors are 0.60 and 0.32 mm.
   It is the only test image in which the reference upper lip lies below the lower lip.
3. `cks2ip8g02asq0yuf59owfht0` and `cks2ip8fq29zp0yuf7cxd3bz2` (ART Plus): molar and second-premolar cusp tips 6-12 mm
   anterior along the occlusal plane; the predicted upper molar lies within 0.2-1.6 mm of the reference upper second premolar.
4. `cl777aklx03ua076whaie06kb` (Rotograph EVO): ear rods over the temporomandibular region; seven landmarks 4-12 mm off.

## For you to decide

- The swapped lip labels in case 2 are an error in the published Aariz annotations. Correcting them would lower the
  Aariz MRE from 1.105 to about 1.097 mm. The manuscript keeps the official annotations and reports the case; say so
  if you prefer the corrected value.
- Case 1 was previously attributed to the "contralateral ramus". The image shows two non-superimposed ear rods and
  predictions about 17 mm anterior to the reference; I described what is visible and did not assert the cause.
- Section 2.1 still contains the placeholder sentence about ethics approval ("Ethics: confirm with your institution ...").
  It must be replaced before submission.
- ISBI 2015 Test1 has two very large sella errors (images 181 and 194: 31.9 and 14.4 mm). They are in the supplement's
  SD for sella (2.811 mm) but are not mentioned in the text.
- Aariz junior and senior annotations are identical or nearly identical for six landmarks (the four molar and premolar
  cusp tips, sella, and two are exactly 0.000 mm apart). The inter-observer figures in 3.2 are therefore not a full
  measure of observer variability for those points.
## Added later on 2026-10-06: GPU verification

- **Released checkpoints reproduce the prediction files** for all four evaluation sets (largest coordinate difference:
  Aariz 0.035 px, ISBI Test1 0.001 px, ISBI Test2 0.000 px, CephAdoAdu 0.000 px; MRE identical to four decimals).
- **Uncertainty on the other datasets.** Spearman rho is 0.61 on Aariz but only 0.14 (ISBI Test1), 0.19 (ISBI Test2)
  and 0.39 (CephAdoAdu). The least confident decile still has the highest MRE on each (1.52, 2.54, 1.63 mm).
  Manuscript: one sentence added to 3.5, the Discussion paragraph now says "On Aariz" and ends with a caution that
  uncertainty-guided review should be validated on the target data, and 2.7 says the analysis was repeated on the
  other evaluation sets. Full table: `results/manuscript_metrics/checkpoint_reproduction_uncertainty.md`.
- **Still running on the Kaggle session (not yet in the manuscript):**
  1. `outputs/ablation_full150` - full model trained with the exact ablation settings (150 epochs, seed 42), to give
     Table 6 a reference row of equal training length. About 4.5 hours.
  2. `outputs/isbi_phase1_seed1` - phase-1 recipe (200 epochs) with seed 1, to check the Table 6 reference row
     (1.188 mm / 84.39%, 1.595 mm / 73.21%) and to give one estimate of seed-to-seed variation. About 6 hours.

---

# Part 10 - Released checkpoints: reproduction of the prediction files and uncertainty on all datasets

Inference re-run with the released weights. 'Max diff' is the largest coordinate difference (original pixels) between the re-run and the saved prediction file. Uncertainty = exp(predicted log-scale) of the last refinement update, converted to millimetres. Correlations and deciles are over all landmark predictions and use the errors of the saved prediction files.

| Evaluation set | Images | Max diff (px) | MRE re-run (mm) | MRE saved (mm) | Spearman rho | Pearson r | Most confident decile: MRE (SDR 2 mm) | Least confident decile: MRE (SDR 2 mm) | Mean error / mean uncertainty | Errors > 4 mm with above-median uncertainty | Errors > 4 mm in least confident decile |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Aariz test | 150 | 0.035 | 1.1051 | 1.1051 | 0.605 | 0.429 | 0.33 (100.0%) | 2.52 (55.1%) | 5.31 | 123/127 | 69/127 |
| ISBI 2015 Test1 | 150 | 0.001 | 1.1238 | 1.1238 | 0.136 | 0.550 | 0.62 (99.6%) | 1.52 (81.4%) | 4.55 | 29/46 | 12/46 |
| ISBI 2015 Test2 | 100 | 0.000 | 1.4632 | 1.4632 | 0.192 | 0.391 | 0.75 (94.2%) | 2.54 (56.8%) | 6.43 | 90/102 | 47/102 |
| CephAdoAdu validation part | 300 | 0.000 | 1.0105 | 1.0105 | 0.387 | 0.383 | 0.46 (99.7%) | 1.63 (73.7%) | 5.09 | 38/44 | 17/44 |

## Deciles of predicted uncertainty

| Evaluation set | Decile | Mean uncertainty (mm) | MRE (mm) | SDR 2 mm (%) | Error / uncertainty |
|---|---|---|---|---|---|
| Aariz test | 1 | 0.069 | 0.330 | 100.0 | 4.77 |
| Aariz test | 2 | 0.102 | 0.462 | 99.7 | 4.52 |
| Aariz test | 3 | 0.130 | 0.526 | 99.2 | 4.04 |
| Aariz test | 4 | 0.150 | 0.711 | 96.9 | 4.73 |
| Aariz test | 5 | 0.170 | 0.904 | 93.8 | 5.32 |
| Aariz test | 6 | 0.191 | 1.148 | 88.2 | 6.02 |
| Aariz test | 7 | 0.215 | 1.370 | 79.2 | 6.37 |
| Aariz test | 8 | 0.247 | 1.469 | 81.5 | 5.96 |
| Aariz test | 9 | 0.294 | 1.614 | 74.6 | 5.49 |
| Aariz test | 10 | 0.515 | 2.517 | 55.1 | 4.89 |
| ISBI 2015 Test1 | 1 | 0.134 | 0.616 | 99.6 | 4.62 |
| ISBI 2015 Test1 | 2 | 0.156 | 1.159 | 87.4 | 7.42 |
| ISBI 2015 Test1 | 3 | 0.182 | 1.303 | 80.4 | 7.15 |
| ISBI 2015 Test1 | 4 | 0.200 | 1.137 | 85.6 | 5.68 |
| ISBI 2015 Test1 | 5 | 0.211 | 1.102 | 87.7 | 5.23 |
| ISBI 2015 Test1 | 6 | 0.223 | 0.925 | 93.0 | 4.15 |
| ISBI 2015 Test1 | 7 | 0.237 | 1.051 | 87.4 | 4.43 |
| ISBI 2015 Test1 | 8 | 0.255 | 1.160 | 87.4 | 4.55 |
| ISBI 2015 Test1 | 9 | 0.278 | 1.266 | 81.4 | 4.56 |
| ISBI 2015 Test1 | 10 | 0.595 | 1.520 | 81.4 | 2.56 |
| ISBI 2015 Test2 | 1 | 0.133 | 0.751 | 94.2 | 5.66 |
| ISBI 2015 Test2 | 2 | 0.156 | 1.504 | 70.0 | 9.64 |
| ISBI 2015 Test2 | 3 | 0.181 | 1.482 | 74.2 | 8.19 |
| ISBI 2015 Test2 | 4 | 0.198 | 1.339 | 75.3 | 6.76 |
| ISBI 2015 Test2 | 5 | 0.209 | 1.207 | 76.8 | 5.79 |
| ISBI 2015 Test2 | 6 | 0.219 | 1.278 | 76.3 | 5.83 |
| ISBI 2015 Test2 | 7 | 0.232 | 1.203 | 83.2 | 5.19 |
| ISBI 2015 Test2 | 8 | 0.248 | 1.430 | 75.3 | 5.76 |
| ISBI 2015 Test2 | 9 | 0.268 | 1.900 | 65.3 | 7.09 |
| ISBI 2015 Test2 | 10 | 0.431 | 2.537 | 56.8 | 5.88 |
| CephAdoAdu validation part | 1 | 0.130 | 0.462 | 99.7 | 3.55 |
| CephAdoAdu validation part | 2 | 0.147 | 0.642 | 97.0 | 4.35 |
| CephAdoAdu validation part | 3 | 0.159 | 0.792 | 94.7 | 4.99 |
| CephAdoAdu validation part | 4 | 0.169 | 0.855 | 94.0 | 5.05 |
| CephAdoAdu validation part | 5 | 0.181 | 1.053 | 89.3 | 5.82 |
| CephAdoAdu validation part | 6 | 0.193 | 0.976 | 91.7 | 5.07 |
| CephAdoAdu validation part | 7 | 0.206 | 1.161 | 88.3 | 5.65 |
| CephAdoAdu validation part | 8 | 0.221 | 1.277 | 85.7 | 5.78 |
| CephAdoAdu validation part | 9 | 0.244 | 1.259 | 82.7 | 5.16 |
| CephAdoAdu validation part | 10 | 0.337 | 1.629 | 73.7 | 4.83 |


## Added 2026-10-06 05:35: matched ablation reference (Table 6)

The full model was retrained on ISBI 2015 with the exact ablation settings (150 epochs, one-cycle, seed 42) so that the
reference row of Table 6 has the same training length as the four variants and can be verified from prediction files
(`results/training_runs/ablation_full150/`). Best validation MRE 1.18 mm at epoch 139.

| Table 6, reference row | Was (phase-1 model, 200 epochs, no prediction file) | Now (150 epochs) |
|---|---|---|
| Test1 MRE / SDR 2 mm | 1.188 mm / 84.39% | 1.180 mm / 85.79% |
| Test2 MRE / SDR 2 mm | 1.595 mm / 73.21% | 1.571 mm / 74.16% |

Other thresholds: Test1 SDR 2.5/3/4 mm = 91.72 / 95.26 / 98.14%; Test2 = 82.16 / 87.84 / 95.16%.

Manuscript edits: Table 6 reference row and footnote; section 2.6 (reference is now the full model trained with the same
150-epoch schedule); section 3.4 (MRE "rose from 1.180 to 12.616 mm"; single refinement update: +0.59 mm and
-20.0 percentage points). The conclusions of the ablation are unchanged; the no-heatmap variant (1.171 mm, 86.18%)
still does not fall below the reference.

**Figure 4 still shows the old reference bars (1.188 and 1.595 mm).** The difference is invisible on its logarithmic
scale, but the figure should be regenerated with 1.180 and 1.571 mm for consistency.


## Added 2026-10-06 07:27: seed replicate on ISBI 2015

The first training phase (200 epochs, one-cycle, max lr 2e-4) was repeated with seed 1 instead of 42
(`results/training_runs/isbi_phase1_seed1/`). Best validation MRE 1.36 mm at epoch 188.

| Run | Test1 MRE / SDR 2 mm | Test2 MRE / SDR 2 mm |
|---|---|---|
| Seed 42, 200 epochs (original phase 1, from the log and the old Table 6) | 1.188 mm / 84.39% | 1.595 mm / 73.21% |
| Seed 42, 150 epochs (matched ablation reference, verified) | 1.180 mm / 85.79% | 1.571 mm / 74.16% |
| Seed 1, 200 epochs (this run, verified) | 1.360 mm / 80.84% | 1.657 mm / 69.00% |

Seed 1, all thresholds (MRE / SDR 2 / 2.5 / 3 / 4 mm): Test1 1.360 mm / 80.84% / 88.42% / 93.23% / 97.12%; Test2 1.657 mm / 69.00% / 78.95% / 86.26% / 94.37%.

What happened in the seed-1 run: the validation error fell to 13 mm by epoch 59, jumped back to about 40 mm at epoch 60
(around the peak learning rate) and only recovered after epoch 95, so the model had fewer effective epochs to converge and
was still improving at the end. One seed is one observation, not an estimate of the spread.

Manuscript edit: one sentence added to the limitations paragraph stating this run-to-run difference and that differences
of that size between configurations (for example full model vs no heatmap head) should not be interpreted.

Not changed, for you to consider:
- The final ISBI model (three phases, 528 epochs) was not re-trained with another seed, so its seed sensitivity is unknown;
  phases 2 and 3 may well close most of this gap.
- Section 3.4 says removing the heatmap head "did not reduce accuracy" (1.171 vs 1.180 mm). That remains true, and the
  new limitation sentence already says such a difference is within run-to-run variation.


## Added 2026-10-06: Figure 4 regenerated

`Figure4_ablation.tif` was redrawn with the new reference bars (Full model: 1.180 mm on Test1, 1.571 mm on Test2) in the same size, format and style as before (1650 x 960 px, 300 dpi, LZW TIFF) and replaced in the submission zip. The other eight bars are unchanged. The old figure is in `updated_manuscript/previous_version/`; the script is `make_figure4.py`. The Fig. 4 legend in the manuscript needed no change.


## Added 2026-10-06 20:25: three-phase seed replicates (interrupted; manuscript not changed)

**The Kaggle session ended about 3 h 50 min after it started, long before the 12-hour limit, so the three-phase runs
did not complete.** The last successful check was at 15:41 UTC; by 16:02 UTC the session no longer existed (the server
returns 404). Nothing in the runs had failed: both were training normally. A session ending this early is usually
Kaggle's idle shutdown (the notebook tab closed or left without interaction), not the 12-hour cap.

## What was running

Two full three-phase runs (200 + 200 + 128 epochs), one per GPU, with mixed-precision arithmetic in the backbone only
(transformers, coordinate heads, losses and metrics in full precision) to bring the 528 epochs from about 16 hours to
about 9: seed 42 as a control for the precision change, and seed 2 as a new seed.

## What was saved

| Run | Stage reached | Test1 MRE / SDR 2 mm | Test2 MRE / SDR 2 mm | Source |
|---|---|---|---|---|
| Seed 42, mixed precision | phase 1 complete; phase 2 at epoch 2 of 200 | 1.166 mm / 85.37% | 1.526 mm / 74.42% | prediction files (saved) |
| Seed 2, mixed precision | phase 1 at epoch 194 of 200 | 1.156 mm / 86.1% (best epoch, 172) | not available | training log only; Test1 is the validation set |

Seed 42 phase 1, all thresholds: Test1 SDR 2 / 2.5 / 3 / 4 mm = 85.37 / 91.65 / 95.40 / 98.11%; Test2 = 74.42 / 82.47 / 88.47 / 94.47%.

No phase-2 or phase-3 result exists, so there is **no new three-phase result** to set against the published
1.124 mm / 87.12% (Test1) and 1.463 mm / 74.74% (Test2).

## What the phase-1 results show

| Phase-1 run (200 epochs) | Precision | Test1 MRE | Test1 SDR 2 mm | Test2 MRE |
|---|---|---:|---:|---:|
| Seed 42, original | full | 1.188 mm | 84.39% | 1.595 mm |
| Seed 42, control | mixed (backbone) | 1.166 mm | 85.37% | 1.526 mm |
| Seed 2 | mixed (backbone) | 1.156 mm | 86.1% | - |
| Seed 1 (run of 2026-10-05/06) | full | 1.360 mm | 80.84% | 1.657 mm |

- Mixed precision did not hurt: with the same seed the result is 1.166 mm against 1.188 mm. The two runs are not
  bit-identical, so this is itself an example of run-to-run variation of about 0.02 mm.
- Seed 2 trained smoothly and reached the same level as seed 42. Three of the four phase-1 runs lie within
  1.156-1.188 mm; seed 1, which diverged near the peak learning rate, is the outlier at 1.360 mm.
- So the picture is: usually a spread of a few hundredths of a millimetre, with an occasional unstable run that ends
  about 0.2 mm worse after phase 1. Whether phases 2 and 3 repair such a run is still unknown.

## Manuscript

**I did not change the manuscript or the supplement this time.** Both were edited at 10:16 on 2026-10-06, after my last
change: the limitations sentence now cites a new Table S7 in the supplement, which lists the phase-1 runs. Rather than
overwrite that wording, here is what could be added if you want the two new runs included.

Two extra rows for Table S7:

| Run | Epochs | Seed | Test1 MRE (mm) | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE (mm) | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|
| Phase 1 repeated, mixed precision in the backbone | 200 | 42 | 1.166 | 85.37 / 91.65 / 95.40 / 98.11 | 1.526 | 74.42 / 82.47 / 88.47 / 94.47 |
| Seed replicate of phase 1, mixed precision in the backbone* | 200 | 2 | 1.156 | 86.1 / 92.1 / 95.3 / 98.1 | - | - |

*From the training log at the best epoch (172); the run was interrupted at epoch 194 and Test2 was not evaluated.

Replacement for the limitations sentence:

> Run-to-run variation was not negligible (Table S7): when the first 200-epoch training phase on ISBI 2015 was repeated
> with two other random seeds, the Test1 MRE was 1.156 mm in one run and 1.360 mm in the other, in which training
> temporarily diverged near the peak learning rate, compared with 1.188 mm originally, so differences of this size
> between configurations, such as that between the full model and the variant without the heatmap head, should not be
> interpreted.

Whether to include them is a judgement call: they make the picture fairer (the 1.360 mm run looks like an outlier, not
the typical spread), but the seed-2 figure comes from a log, not from saved predictions, and both runs used mixed
precision, which the Methods would then have to mention.

## To finish the three-phase replicates

It needs one uninterrupted session of about 9.5 hours. What makes that survive:

- Start it as a **committed run** ("Save Version" -> "Save & Run All") instead of an interactive session. Committed
  runs do not depend on a browser tab and keep `/kaggle/working` as output afterwards. That requires the commands to
  be cells in the notebook; I can write that notebook for you.
- Or keep an interactive session's tab open and in the foreground for the whole time.

Scripts are ready: `train_fast.py` (seed and backbone mixed precision) and `job3p.sh` (three phases with inference
after each) can be recreated in minutes in a new session.

Saved files: `results/training_runs_3phase/`.


## Added 2026-10-08: three-phase seed replicates on ISBI 2015 - complete (manuscript not changed; proposals below)

Both runs finished all three phases (200 + 200 + 128 epochs). The complete recipe was repeated twice with
mixed-precision arithmetic in the backbone: once with the published seed (42) and once with a new seed (2).

## Final results (three phases)

| Model | Seed | Precision | Test1 MRE +/- SD (mm) | Test1 MRE 95% CI | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE +/- SD (mm) | Test2 MRE 95% CI | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|---|---|
| Published model | 42 | full | 1.124 +/- 1.076 | 1.082-1.169 | 87.12 / 92.53 / 96.11 / 98.39 | 1.463 +/- 1.385 | 1.419-1.508 | 74.74 / 83.47 / 88.84 / 94.63 |
| Replicate | 42 | mixed (backbone) | 1.102 +/- 0.942 | 1.063-1.145 | 87.40 / 92.21 / 95.68 / 98.35 | 1.426 +/- 1.280 | 1.386-1.467 | 76.74 / 83.21 / 88.89 / 95.00 |
| Replicate | 2 | mixed (backbone) | 1.122 +/- 0.943 | 1.081-1.165 | 87.05 / 92.53 / 95.61 / 98.32 | 1.462 +/- 1.467 | 1.406-1.532 | 75.42 / 83.00 / 88.74 / 94.95 |

Across the three complete runs: Test1 MRE 1.102-1.124 mm and SDR at 2 mm 87.05-87.40%; Test2 MRE 1.426-1.463 mm and
SDR at 2 mm 74.74-76.74%. 95% CIs: percentile bootstrap, 10,000 image-level resamples.

## By phase

| Seed | Phase | Epochs | Best validation MRE (mm) | Test1 MRE (mm) / SDR 2 mm (%) | Test2 MRE (mm) / SDR 2 mm (%) |
|---|---|---|---|---|---|
| 42 | 1 | 200 | 1.171 | 1.171 / 85.75 | 1.532 / 75.11 |
| 42 | 2 | 200 | 1.102 | 1.102 / 87.40 | 1.426 / 76.74 |
| 42 | 3 | 128 | 1.102 (no improvement; best phase-3 epoch 1.121) | 1.102 / 87.40 | 1.426 / 76.74 |
| 2 | 1 | 200 | 1.171 | 1.171 / 85.47 | 1.556 / 74.47 |
| 2 | 2 | 200 | 1.122 | 1.122 / 86.91 | 1.482 / 75.63 |
| 2 | 3 | 128 | 1.122 | 1.122 / 87.05 | 1.462 / 75.42 |

For seed 42 the third phase never beat the phase-2 checkpoint, so its final model is the phase-2 one (the predictions
are identical). For seed 2 the third phase produced a marginally better checkpoint. This matches the manuscript's
remark about diminishing returns from further fine-tuning.

## Paired differences in per-image error (same images)

| Comparison | Test1: mean difference in mm (95% CI) | Test2: mean difference in mm (95% CI) |
|---|---|---|
| Published - seed 42 replicate | +0.022 (+0.005 to +0.042) | +0.037 (+0.014 to +0.066) |
| Published - seed 2 replicate | +0.002 (-0.016 to +0.024) | +0.001 (-0.055 to +0.036) |
| Seed 42 replicate - seed 2 replicate | -0.019 (-0.033 to -0.007) | -0.037 (-0.094 to +0.001) |

## What this shows

- **The published three-phase result is reproducible.** The new seed gives 1.122 mm / 1.462 mm against the published
  1.124 mm / 1.463 mm: differences of 0.002 and 0.001 mm.
- **Run-to-run spread of the complete recipe is about 0.02 mm on Test1 and 0.04 mm on Test2**, i.e. well inside the
  bootstrap confidence intervals of each run.
- **The same-seed replicate is not identical to the published model** (1.102 vs 1.124 mm). It differs in precision
  mode and hardware, and it was resumed from saved state several times; it is slightly better, not worse, so mixed
  precision did not harm accuracy.
- **The unstable phase-1 run with seed 1 (1.360 mm) was not typical.** Phase 1 gave 1.171 mm for both seeds here and
  1.188 mm originally. Whether phases 2 and 3 would have repaired the seed-1 run was not tested.

## Practical notes on how the runs were made

- Mixed precision (16-bit) in the convolutional backbone only; transformer encoders, coordinate heads, losses and
  metrics in 32-bit. About 63 s per epoch instead of about 110 s.
- The Kaggle sessions ended early four times. Training state was saved every epoch and uploaded to Hugging Face every
  30 minutes, and each run continued from its last completed epoch on a new session (phase 1 at epochs 53/55, phase 2
  at epochs 138/158). A resumed run is not bit-identical to an uninterrupted one.

## Proposed additions for the manuscript (not applied - you edit these files)

Table S7 currently lists first-phase runs only. Suggested: retitle it "Additional training runs of the full model on
ISBI 2015" and add these rows (and drop the footnote sentence "The final ISBI 2015 model (three phases, 528 epochs) was
not repeated with another seed"):

| Run | Epochs | Seed | Test1 MRE (mm) | Test1 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) | Test2 MRE (mm) | Test2 SDR 2.0 / 2.5 / 3.0 / 4.0 (%) |
|---|---|---|---|---|---|---|
| Final model (three phases), as reported | 528 | 42 | 1.124 | 87.12 / 92.53 / 96.11 / 98.39 | 1.463 | 74.74 / 83.47 / 88.84 / 94.63 |
| Three-phase replicate* | 528 | 42 | 1.102 | 87.40 / 92.21 / 95.68 / 98.35 | 1.426 | 76.74 / 83.21 / 88.89 / 95.00 |
| Three-phase replicate* | 528 | 2 | 1.122 | 87.05 / 92.53 / 95.61 / 98.32 | 1.462 | 75.42 / 83.00 / 88.74 / 94.95 |
| Phase 1 of the replicate* | 200 | 42 | 1.171 | 85.75 / 91.72 / 95.05 / 97.93 | 1.532 | 75.11 / 82.47 / 88.21 / 94.95 |
| Phase 1 of the replicate* | 200 | 2 | 1.171 | 85.47 / 91.75 / 95.51 / 98.14 | 1.556 | 74.47 / 82.47 / 88.05 / 94.84 |

*Trained with mixed-precision arithmetic in the backbone.

Replacement for the limitations sentences (from "Fifth, each configuration was trained once ..." up to "... should not
be interpreted."):

> Fifth, the Aariz and CephAdoAdu models and the ablation variants were each trained once, so their confidence
> intervals reflect sampling of the evaluation images only, and the ablation variants were trained for fewer epochs
> than the final models. For ISBI 2015, the complete three-phase training was repeated twice, with the original and
> with a different random seed (Table S7): the Test1 MRE was 1.102 and 1.122 mm, against 1.124 mm for the reported
> model, and the Test2 MRE 1.426 and 1.462 mm against 1.463 mm, so run-to-run variation of the full recipe was about
> 0.02-0.04 mm. Single 200-epoch runs varied more: one repetition of the first phase became temporarily unstable near
> the peak learning rate and ended at 1.360 mm instead of 1.17-1.19 mm, so differences of a few hundredths of a
> millimetre between ablation variants, such as that between the full model and the variant without the heatmap head,
> should not be interpreted.

If you adopt this, add one clause to section 2.5 or to the Table S7 footnote: "the replicate runs used mixed-precision
arithmetic in the convolutional backbone to shorten training".

## Where everything is

- Hugging Face, `main` branch of `emad2001/DeLR-Cephalometric-ConvNeXtV2`: `checkpoints/ISBI2015_seed_replicates/`
  (logs, predictions for every phase, the two final checkpoints, `train_fast.py`, `job3p.sh`).
- Local: `results/training_runs_3phase/` (logs, metrics, predictions, `final_metrics_with_ci.json`).
- The work branch `seedrep-wip-27` on Hugging Face holds the last rolling training state and is no longer needed.
- The earlier interrupted attempt is in `results/training_runs_3phase_interrupted_2026-10-06/`.
